// ============================================================
// Three more minigames, each hung on a beat that already exists:
//   'solder'  Ruth's radio on Walter's bench: four cold joints, then the dial
//   'weather' the KHRL forecast off the teletype, against the ON AIR light
//   'dig'     Hector's lot, in the rhythm of the rain, with something buried
// None of them pays money. They pay a line, a station, a trowel.
// ============================================================
{
  const sm0 = startMinigame;
  startMinigame = function (kind, onDone) {
    if (kind === 'solder' || kind === 'weather' || kind === 'dig') {
      MG.onDone = onDone; MG.cur = kind === 'solder' ? new SolderGame() : kind === 'weather' ? new WeatherGame() : new DigGame(); MG.cur.start(); G.state = 'minigame'; return;
    }
    return sm0(kind, onDone);
  };
}
function mgIntro(g, lines, y) { const w = 280; UI.panel(g, W / 2 - w / 2, y || 196, w, 12 + lines.length * 10, 0.95); lines.forEach((l, i) => drawText(g, l, W / 2, (y || 196) + 6 + i * 10, i === 0 ? '#f0ead8' : '#c8ccd8', { align: 'center' })); }

// ---------- RUTH'S RADIO ----------
// Hold E to heat a joint; let go while it is shiny. Then find a station on the dial and hold it.
const STATIONS = [
  { id: 'ball', pos: 0.22, name: 'a ball game', notes: [392, 392, 440, 392, 523, 494] },
  { id: 'hymn', pos: 0.58, name: 'the Sunday station', notes: [330, 392, 440, 392, 330, 294] },
  { id: 'band', pos: 0.84, name: 'big band', notes: [440, 554, 659, 554, 440, 659] },
];
class SolderGame {
  start() {
    this.t = 0; this.intro = 170; this.over = 0; this.phase = 'solder'; this.sel = 0; this.burns = 0; this.done = 0;
    this.joints = [0, 1, 2, 3].map(i => ({ x: 150 + i * 58, y: 132 + (i % 2) * 18, heat: 0, state: 0, cool: 0 })); // state 0 cold, 1 shiny, 2 burnt
    this.dial = 0.05; this.lock = 0; this.station = null; this.smoke = []; this.noiseT = 0;
  }
  update() {
    if (this.intro > 0) { this.intro--; if (Input.anyHit()) this.intro = 0; return; }
    if (this.over > 0) { this.over--; if (this.over === 0 || Input.hit('act')) this.finish(); return; }
    this.t++;
    if (this.phase === 'solder') {
      if (Input.hit('left')) this.sel = (this.sel + 3) % 4; if (Input.hit('right')) this.sel = (this.sel + 1) % 4;
      if (Input.hit('up') || Input.hit('down')) this.sel = (this.sel + 2) % 4;
      for (let i = 0; i < 4; i++) { const j = this.joints[i]; if (j.state === 2) { j.cool--; if (j.cool <= 0) { j.state = 0; j.heat = 0; } continue; } if (j.state === 1) continue;
        if (i === this.sel && Input.held('act')) { j.heat = Math.min(1, j.heat + 0.011); if (this.t % 6 === 0) this.smoke.push({ x: j.x + rnd(-2, 2), y: j.y - 4, t: 30 }); if (this.t % 9 === 0) Audio.tone(60 + j.heat * 40, 0.05, 'sawtooth', 0.012); if (j.heat >= 0.97) { j.state = 2; j.cool = 90; this.burns++; Audio.bad(); } }
        else if (j.heat > 0) { if (j.heat >= 0.55 && j.heat < 0.9) { j.state = 1; this.done++; Audio.tone(1200, 0.08, 'square', 0.04); } else j.heat = Math.max(0, j.heat - 0.02); }
      }
      if (this.done >= 4) { this.phase = 'tune'; Audio.tone(300, 0.2, 'triangle', 0.03, 1.5); }
    } else {
      const sp = 0.0045; if (Input.held('left')) this.dial = Math.max(0, this.dial - sp); if (Input.held('right')) this.dial = Math.min(1, this.dial + sp);
      let best = null, sig = 0; for (const s of STATIONS) { const d = Math.abs(s.pos - this.dial); const v = Math.max(0, 1 - d / 0.07); if (v > sig) { sig = v; best = s; } }
      this.sig = sig;
      if (this.t % 5 === 0 && sig < 0.95) Audio.tone(rnd(90, 380), 0.05, 'sawtooth', 0.014 * (1 - sig * 0.8));
      if (sig > 0.8 && best) { this.lock++; if (this.lock % 10 === 0) { const n = best.notes[(this.lock / 10) % best.notes.length]; Audio.tone(n, 0.14, 'triangle', 0.03 * sig); } if (this.lock >= 90) { this.station = best; this.over = 170; } } else this.lock = 0;
    }
    for (const s of this.smoke) { s.y -= 0.4; s.t--; } this.smoke = this.smoke.filter(s => s.t > 0);
  }
  finish() { endMinigame(0, [this.station ? this.station.id : 'ball', this.burns]); }
  draw(g, t) {
    mgFrame(g, "RUTH'S RADIO - THE BENCH", this.phase === 'solder' ? `joints ${this.done}/4   scorched ${this.burns}` : 'find a station and hold it');
    // the radio, open on the bench
    px(g, 110, 96, 260, 92, '#5a4a36'); px(g, 110, 96, 260, 2, '#7a6a4a'); px(g, 112, 100, 256, 84, '#2a2620'); px(g, 120, 108, 240, 70, '#3a5a3a'); // board
    for (let i = 0; i < 12; i++) px(g, 124 + i * 20, 110, 1, 66, '#2f4a2f'); for (let i = 0; i < 6; i++) px(g, 120, 112 + i * 12, 240, 1, '#2f4a2f');
    // capacitor and traces
    px(g, 300, 118, 14, 26, '#3a3a48'); px(g, 302, 118, 10, 2, '#8a8aa0'); px(g, 206, 150, 100, 1, '#b8a060'); px(g, 150, 150, 60, 1, '#b8a060');
    for (let i = 0; i < 4; i++) { const j = this.joints[i]; px(g, j.x - 1, j.y - 12, 3, 12, '#9a9aa8');
      const col = j.state === 1 ? '#e8e8f0' : j.state === 2 ? '#4a2a1a' : `rgb(${120 + j.heat * 135},${110 + j.heat * 60},${90})`;
      g.fillStyle = col; g.beginPath(); g.arc(j.x, j.y, j.state === 1 ? 4 : 3 + j.heat * 2, 0, Math.PI * 2); g.fill(); if (j.state === 1) px(g, j.x - 1, j.y - 2, 1, 1, '#ffffff');
      if (this.phase === 'solder' && i === this.sel) { g.strokeStyle = '#e8c84a'; g.strokeRect(j.x - 8.5, j.y - 8.5, 17, 17); // heat bar
        px(g, j.x - 10, j.y + 12, 20, 4, '#1a1e24'); px(g, j.x - 10 + 11, j.y + 12, 7, 4, 'rgba(138,232,138,0.35)'); px(g, j.x - 10, j.y + 12, Math.round(20 * j.heat), 4, j.heat > 0.9 ? '#e86a6a' : j.heat >= 0.55 ? '#8ae88a' : '#e8a020'); }
    }
    // iron
    if (this.phase === 'solder') { const j = this.joints[this.sel]; const hot = Input.held('act'); px(g, j.x + 4, j.y - 30, 3, 26, '#8a8a92'); px(g, j.x + 3, j.y - 46, 5, 18, '#3a3a44'); if (hot) px(g, j.x + 4, j.y - 4, 3, 3, '#ffb060'); }
    for (const s of this.smoke) { g.fillStyle = `rgba(200,200,210,${s.t / 60})`; g.fillRect(s.x, s.y, 2, 2); }
    // dial
    if (this.phase === 'tune') {
      px(g, 130, 196, 220, 18, '#1a1a20'); px(g, 130, 196, 220, 1, '#4a4a56'); for (let i = 0; i <= 10; i++) px(g, 130 + i * 22, 208, 1, 4, '#6a6a76');
      for (const s of STATIONS) px(g, 130 + Math.round(s.pos * 220), 200, 1, 6, 'rgba(232,200,74,0.25)');
      px(g, 130 + Math.round(this.dial * 220), 197, 1, 16, '#e86a6a');
      // static / signal
      const sig = this.sig || 0; for (let i = 0; i < 30; i++) { const h = Math.round(rnd(1, 8) * (1 - sig) + (sig > 0.8 ? 3 + 2 * Math.sin(t * 0.3 + i) : 0)); px(g, 132 + i * 7, 226 - h, 4, h, sig > 0.8 ? '#8ae88a' : '#5a5a66'); }
      drawText(g, sig > 0.8 ? 'hold it...' : sig > 0.3 ? 'something' : 'static', W / 2, 232, sig > 0.8 ? '#8ae88a' : '#8a92a4', { align: 'center' });
      if (this.lock > 0) px(g, 190, 240, Math.round(100 * this.lock / 90), 2, '#e8c84a');
    }
    if (this.intro > 0) mgIntro(g, ['The capacitor is in. Four joints to make.', 'ARROWS pick a joint. HOLD E to heat it; let go', 'while the bar is green. Any key to start.'], 200);
    else if (this.over > 0) { UI.panel(g, W / 2 - 110, 236, 220, 22, 0.95); drawText(g, `${this.station ? this.station.name : 'a station'}, tinny and warm.`, W / 2, 242, '#e8c84a', { align: 'center' }); }
    else UI.drawHint(g, this.phase === 'solder' ? 'HOLD E to heat, release while green' : 'LEFT / RIGHT to tune');
  }
}
{
  const fr0 = Walter.fixRadio;
  Walter.fixRadio = function () {
    startMinigame('solder', (pay, res) => {
      const w = C('walter'); w.station = res[0]; const burns = res[1];
      fr0.call(this);
      if (!Dlg.active) return; const s = STATIONS.find(x => x.id === w.station) || STATIONS[0];
      // replace the ball-game ending with the station you actually found
      const i = Dlg.steps.findIndex(x => x && x.say === 'walter' && /Kessler/.test(x.text || '')); if (i >= 0) {
        const line = s.id === 'ball' ? "That's Kessler. He's been calling games since I was fifty." : s.id === 'hymn' ? "...That's the Sunday station. Ruth's. She'd have it on while she did the crossword and I'd pretend I wasn't listening." : "...Big band. 1962 wasn't the year for it. It was the year we didn't care.";
        Dlg.steps[i] = say('walter', line); const j = Dlg.steps.findIndex(x => x && x.say === 'narrator' && /calling a ball game/.test(x.text || '')); if (j >= 0) Dlg.steps[j] = narr(`Static. Then ${s.name}, tinny and warm.`);
      }
      if (burns >= 3) Dlg.steps.splice(Dlg.steps.length - 1, 0, say('walter', "You cooked it some. It'll smell like that for a week. Ruth's did too, the first time I opened it."));
      else if (burns === 0) Dlg.steps.splice(Dlg.steps.length - 1, 0, say('walter', "Clean joints. Ruth's brother would've said so, and he never said so about anything."));
    });
  };
  FRESH.walter = FRESH.walter || []; FRESH.walter.push(
    L_("The Sunday station's on in the mornings now. I don't believe any of it. I believe she did, and that's most of it.", () => G.chars.walter.station === 'hymn'),
    L_("The band station plays the same forty records. I know all forty. I knew them the first time.", () => G.chars.walter.station === 'band'),
    L_("Kessler called a triple last night. Nobody's hit a triple in that park since 1988; I'd have said so if you'd asked.", () => G.chars.walter.station === 'ball'));
}

// ---------- THE FORECAST ----------
// The page in pencil is the truth. The teletype offers three lines a beat; pick the one the page says before the light goes green.
class WeatherGame {
  start() {
    this.t = 0; this.intro = 190; this.over = 0; this.k = 0; this.sel = 0; this.stumbles = 0; this.flick = 0; this.said = [];
    const k = G.weather || 'rain', tm = Weather.kind(G.day + 1); const heavy = G.rain > 0.7 || G.snowing > 0.75;
    const w1 = { rain: 'Rain tonight,', sleet: 'Sleet tonight,', snow: 'Snow tonight,', grey: 'Cloud tonight,', clear: 'Clear tonight,' }[k];
    const w2 = { rain: heavy ? 'heavier after midnight,' : 'lighter after midnight,', sleet: 'turning to rain by two,', snow: heavy ? 'four inches by morning,' : 'an inch, maybe two,', grey: 'no break in it,', clear: 'and cold, the kind that cracks,' }[k];
    const river = G.rain > 0.5 ? 'the river up a foot at the dock,' : G.snowing > 0.5 ? 'the river holding at the dock,' : 'the river down a hair at the dock,';
    const wind = pick(['wind out of the west,', 'wind out of the north,', 'no wind to speak of,']);
    const tmw = { rain: 'and rain again tomorrow.', sleet: 'and sleet tomorrow.', snow: 'and snow tomorrow.', grey: 'and grey tomorrow.', clear: 'and sun tomorrow, for once.' }[tm];
    this.truth = [w1, w2, river, wind, tmw];
    const short = { 'heavier after midnight,': 'HEAVIER AFTER 12', 'lighter after midnight,': 'LIGHTER AFTER 12', 'turning to rain by two,': 'RAIN BY 2AM', 'four inches by morning,': '4 IN. BY MORNING', 'an inch, maybe two,': '1 IN., MAYBE 2', 'no break in it,': 'NO BREAK', 'and cold, the kind that cracks,': 'COLD. CRACKING COLD', 'the river up a foot at the dock,': 'RIVER UP 1 FT (DOCK)', 'the river holding at the dock,': 'RIVER HOLDING (DOCK)', 'the river down a hair at the dock,': 'RIVER DOWN (DOCK)', 'wind out of the west,': 'WIND W', 'wind out of the north,': 'WIND N', 'no wind to speak of,': 'NO WIND' };
    this.page = [w1.replace(' tonight,', '').toUpperCase(), short[w2], short[river], short[wind], tmw.replace(/^and /, '').replace(/,? ?(again )?tomorrow.*$/, '').toUpperCase() + ' TMRW'];
    const swap = s => { const alts = { 'Rain': 'Snow', 'Snow': 'Rain', 'Sleet': 'Rain', 'Cloud': 'Rain', 'Clear': 'Cloud', 'heavier': 'lighter', 'lighter': 'heavier', 'after': 'before', 'up a foot': 'down a foot', 'down a hair': 'up a hair', 'holding': 'up a foot', 'dock': 'bridge', 'west': 'east', 'north': 'south', 'no wind': 'wind', 'tomorrow': 'Thursday', 'four inches': 'a foot', 'an inch': 'a foot', 'two,': 'four,', 'cracks': 'holds', 'sun': 'sleet', 'again': 'gone' }; for (const a of Object.keys(alts)) if (s.includes(a)) return s.replace(a, alts[a]); return s + ' maybe.'; };
    this.rounds = this.truth.map((tr, i) => { const d1 = swap(tr); let d2 = swap(d1); if (d2 === tr || d2 === d1) d2 = swap(tr + ' ').trim(); const opts = [tr, d1, d2]; for (let j = opts.length - 1; j > 0; j--) { const r = irnd(0, j); [opts[j], opts[r]] = [opts[r], opts[j]]; } return { opts, ans: opts.indexOf(tr), limit: Math.round(200 - i * 22) }; });
    this.timer = this.rounds[0].limit;
  }
  update() {
    if (this.intro > 0) { this.intro--; if (Input.anyHit()) this.intro = 0; return; }
    if (this.over > 0) { this.over--; if (this.over === 0 || Input.hit('act')) endMinigame(0, [this.stumbles]); return; }
    this.t++; if (this.flick > 0) this.flick--;
    const r = this.rounds[this.k]; this.timer--;
    if (Input.hit('up')) this.sel = (this.sel + 2) % 3; if (Input.hit('down')) this.sel = (this.sel + 1) % 3; const d = Input.digit(); if (d >= 1 && d <= 3) this.sel = d - 1;
    let pickIdx = null; if (Input.hit('act')) pickIdx = this.sel; if (this.timer <= 0) pickIdx = -1;
    if (pickIdx !== null) {
      if (pickIdx === r.ans) { this.said.push(this.truth[this.k]); Audio.tone(700, 0.05, 'square', 0.03); }
      else { this.stumbles++; this.flick = 24; this.said.push('uh,'); this.said.push(this.truth[this.k]); Audio.tone(180, 0.15, 'sawtooth', 0.03); }
      this.k++; this.sel = 0; if (this.k >= this.rounds.length) { this.over = 160; Audio.tone(520, 0.2, 'triangle', 0.03); } else this.timer = this.rounds[this.k].limit;
    }
  }
  draw(g, t) {
    mgFrame(g, 'KHRL 1340 - THE FORECAST', `line ${Math.min(this.k + 1, 5)}/5   stumbles ${this.stumbles}`);
    // the page, in pencil
    px(g, 34, 44, 118, 74, '#d8d0b8'); px(g, 34, 44, 118, 1, '#f0ead8'); px(g, 36, 46, 114, 70, '#e4dcc4'); drawText(g, 'TONIGHT', 40, 50, '#5a5040');
    this.page.forEach((l, i) => drawText(g, l.length > 20 ? l.slice(0, 20) : l, 40, 62 + i * 12, i === this.k ? '#2a2020' : '#7a7060'));
    if (this.k < 5) px(g, 36, 61 + this.k * 12, 114, 10, 'rgba(232,200,74,0.18)');
    // the ON AIR light with the countdown ring
    const r = this.rounds[Math.min(this.k, 4)]; const frac = this.over ? 0 : clamp(this.timer / r.limit, 0, 1);
    px(g, 34, 122, 118, 18, '#1a1a20'); const red = this.flick % 6 < 3 && this.flick > 0 ? '#3a1a1a' : frac > 0 ? '#e83a3a' : '#3ae86a'; px(g, 37, 125, 78, 12, red); drawText(g, 'ON AIR', 76, 127, '#1a0a0a', { align: 'center' });
    px(g, 119, 125, 30, 12, '#2a2a30'); px(g, 119, 125 + 12 - Math.round(12 * frac), 30, Math.round(12 * frac), frac < 0.3 ? '#e8a020' : '#e8c84a');
    // the teletype strip
    px(g, 160, 44, 282, 96, '#2a2a30'); px(g, 162, 46, 278, 92, '#3a3a42'); drawText(g, 'TELETYPE', 301, 50, '#8a92a4', { align: 'center' });
    if (this.k < 5 && !this.over) r.opts.forEach((o, i) => { const y = 66 + i * 22; const on = i === this.sel; px(g, 166, y - 3, 270, 18, on ? 'rgba(232,200,74,0.18)' : 'rgba(0,0,0,0.15)'); drawText(g, `${i + 1}`, 171, y + 1, on ? '#e8c84a' : '#6a7280'); drawText(g, o, 182, y + 1, on ? '#f0ead8' : '#b8c0d0'); });
    // the transcript, what went out
    px(g, 34, 150, 408, 74, '#0e1218'); px(g, 34, 150, 408, 1, '#2a3038'); drawText(g, 'went out:', 40, 154, '#6a7280');
    let x = 40, y = 166; for (const s of this.said) { const w = textWidth(s) + 6; if (x + w > 436) { x = 40; y += 11; } drawText(g, s, x, y, s === 'uh,' ? '#e86a6a' : '#c8ccd8'); x += w; }
    if (!this.over && this.k < 5) { px(g, x, y, 4, 7, t % 30 < 15 ? '#e8c84a' : 'transparent'); }
    if (this.intro > 0) mgIntro(g, ['The page in pencil is the forecast. The teletype', 'offers three lines; UP/DOWN or 1-3 and E to pick the one', 'the page says before the light goes green. Any key.'], 228);
    else if (this.over > 0) { UI.panel(g, W / 2 - 120, 232, 240, 22, 0.95); drawText(g, this.stumbles === 0 ? 'Clean. Ninety seconds, no uh.' : `${this.stumbles} uh${this.stumbles === 1 ? '' : 's'}. The river does not say uh.`, W / 2, 238, '#e8c84a', { align: 'center' }); }
    else UI.drawHint(g, 'UP/DOWN pick, E read it');
  }
}
{
  // the shift: read the weather live, then the phone
  Radio.shift = function () {
    const r = this.S(); if (G.energy < 8) return;
    startMinigame('weather', (pay, res) => {
      const st = res[0]; useEnergy(8); r.shifts++; r.lastShift = G.day; r.pay += 15; addMoney(15); markTalked(); remember('birdie_shift'); r.reads = (r.reads || 0) + 1; if (st === 0) r.cleanReads = (r.cleanReads || 0) + 1;
      const calls = this.pickCallers(3, true);
      const L = [narr(r.shifts === 1 ? 'She hands you the page first, the forecast in pencil, and then the teletype starts and you read it against the light.' : 'The page, the teletype, the light. You know the rhythm now; it does not make the light any slower.')];
      if (st === 0) L.push(say('birdie', r.shifts === 1 ? "That's it. That's the whole job. You did it clean the first time and I've been doing it in ninety seconds for thirty-one years. Now the phone." : "Clean. Now the phone."));
      else L.push(say('birdie', st >= 3 ? `Four... ${st} uhs. The river doesn't say uh. Nobody died. Now the phone.` : `${st === 1 ? 'One uh' : 'Two uhs'}. The spoons man averaged six. Now the phone.`));
      for (const c of calls) L.push(...c.lines);
      if (!calls.length) L.push(narr('The phone does not ring. She lets it not ring for four minutes, on air, and then says "that was the phone" and puts on a record.'));
      if (st === 0) {
        L.push(narr('One more, late, after she has reached for the record.'), say('caller', "I don't know you. I don't know her, either; I've had it on eleven years and never called. You sounded like you meant it. That's all. I'm going to hang up now."), say('you', "...Thank you."));
        if (r.leaseKnown && !r.lease && !r.callinDay && !r.pledges.includes('listener') && G.day <= LEASE_DAY) { r.pledges.push('listener'); L.push(say('birdie', "Eleven years. Write that one down; if we ever need the phone to ring on purpose, that's a number that will."), narr('A listener who will call. One more toward the night the street calls in.')); }
      }
      L.push(narr(`An hour of it. At the end she takes fifteen dollars out of a coffee can and does not call it pay.${r.shifts === 3 ? ' "Three nights. That\'s more than the spoons man did."' : ''}`));
      Dlg.run(L);
    });
  };
  const pc0 = Radio.pickCallers; Radio.pickCallers = function (n, onAir, prefer) {
    const out = pc0.call(this, n, onAir, prefer); const r = this.S();
    if (prefer && prefer.includes('listener') && !onAir && !out.some(c => c.id === 'listener')) out.push({ id: 'listener', lines: [say('caller', "Eleven years. I said I'd call if it mattered. It matters, apparently. I'm listening; that's my whole message."), say('birdie', "...That's the one who never calls. Well. You did.")] });
    return out;
  };
}

// ---------- HECTOR'S LOT ----------
// Weeds pull in one, roots in three, rocks in two. Dig on the drip of the rain and it counts double. Something is buried.
const FINDS = [
  { id: 'trowel', name: "Hector's trowel", flag: 'hectorTrowel', mem: 'hector_trowel', line: 'A trowel, the handle wrapped in tape gone hard as wood. H.O. burned into the tape with a nail.' },
  { id: 'cap', name: 'a 1974 bottle cap', flag: 'hectorCap', mem: 'hector_cap', line: 'A bottle cap, rust-pink, the year still legible: 1974. Somebody sat here with a beer and watched the beans.' },
  { id: 'marble', name: 'a marble', flag: 'hectorMarble', mem: 'hector_marble', line: "A marble, cat's-eye, green. Not Hector's. Somebody smaller." },
];
class DigGame {
  start() {
    const s = Garden.S(); this.session = s.cleared; this.t = 0; this.intro = 190; this.over = 0; this.cx = 0; this.cy = 0; this.stamina = 46; this.digs = 0; this.onBeat = 0; this.beat = 32; this.pop = null; this.find = null; this.cleared = 0;
    const cols = 10, rows = 4; this.cols = cols; this.rows = rows; this.cells = [];
    const bag = []; for (let i = 0; i < 22; i++) bag.push('weed'); for (let i = 0; i < 8; i++) bag.push('root'); for (let i = 0; i < 4; i++) bag.push('rock'); for (let i = 0; i < 6; i++) bag.push('dirt');
    for (let j = bag.length - 1; j > 0; j--) { const r = irnd(0, j); [bag[j], bag[r]] = [bag[r], bag[j]]; }
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) { const k = bag[y * cols + x]; this.cells.push({ x, y, k, hp: k === 'weed' ? 1 : k === 'root' ? 3 : k === 'rock' ? 2 : 0, done: k === 'dirt', wob: 0 }); }
    this.total = this.cells.filter(c => !c.done).length;
    const finds = FINDS.filter(f => !G.flags[f.flag]); if (finds.length) { const roots = this.cells.filter(c => c.k === 'root'); const c = roots[irnd(0, roots.length - 1)]; c.buried = finds[0]; }
  }
  update() {
    if (this.intro > 0) { this.intro--; if (Input.anyHit()) this.intro = 0; return; }
    if (this.over > 0) { this.over--; if (this.over === 0 || Input.hit('act')) endMinigame(0, [this.cleared / this.total, this.find, this.onBeat, this.digs]); return; }
    this.t++; if (this.pop) { this.pop.t--; if (this.pop.t <= 0) this.pop = null; }
    if (Input.hit('left')) this.cx = Math.max(0, this.cx - 1); if (Input.hit('right')) this.cx = Math.min(this.cols - 1, this.cx + 1);
    if (Input.hit('up')) this.cy = Math.max(0, this.cy - 1); if (Input.hit('down')) this.cy = Math.min(this.rows - 1, this.cy + 1);
    if (this.t % this.beat === 0) Audio.tone(160, 0.05, 'sine', 0.025);
    if (Input.hit('act') && this.stamina > 0) {
      const c = this.cells[this.cy * this.cols + this.cx]; this.digs++; this.stamina--;
      const ph = this.t % this.beat; const on = ph <= 5 || ph >= this.beat - 5; if (on) this.onBeat++;
      if (!c.done) { c.hp -= on ? 2 : 1; c.wob = 10; Audio.tone(on ? 240 : 200, 0.06, 'square', on ? 0.04 : 0.025); if (c.hp <= 0) { c.done = true; this.cleared++; if (c.buried) { this.find = c.buried; this.pop = { x: c.x, y: c.y, t: 120, name: c.buried.name }; Audio.coin(); } } }
      else Audio.tone(120, 0.05, 'triangle', 0.02);
    }
    for (const c of this.cells) if (c.wob > 0) c.wob--;
    if (this.stamina <= 0 && !this.pop || this.cleared >= this.total) { if (!this.over) this.over = 150; }
  }
  draw(g, t) {
    mgFrame(g, "HECTOR'S LOT - " + (this.session === 0 ? 'THE WEEDS' : 'THE ROOTS'), `cleared ${this.cleared}/${this.total}   digs left ${this.stamina}`);
    const ox = 60, oy = 70, cw = 36, ch = 30;
    px(g, ox - 4, oy - 4, this.cols * cw + 8, this.rows * ch + 8, '#3a2e22'); // the bed edge
    for (const c of this.cells) { const x = ox + c.x * cw, y = oy + c.y * ch; const w = c.wob ? Math.sin(c.wob) * 1.5 : 0;
      px(g, x, y, cw, ch, c.done ? '#2e2418' : '#3e3226'); px(g, x, y, cw, 1, '#4a3c2c');
      if (!c.done) {
        if (c.k === 'weed') { for (let i = 0; i < 5; i++) { const gx = x + 5 + i * 6 + w; px(g, gx, y + 8 + (i % 2) * 3, 2, ch - 12, '#4a7a3a'); px(g, gx - 2, y + 6 + (i % 2) * 3, 6, 2, '#5a8a44'); } }
        else if (c.k === 'root') { g.strokeStyle = c.hp === 3 ? '#7a5a3a' : c.hp === 2 ? '#6a4a30' : '#553a26'; g.lineWidth = 2; g.beginPath(); g.moveTo(x + 4 + w, y + 6); g.lineTo(x + 16, y + 14); g.lineTo(x + 8, y + 24); g.moveTo(x + 16, y + 14); g.lineTo(x + 30 + w, y + 10); g.lineTo(x + 26, y + 26); g.stroke(); if (c.hp < 3) px(g, x + 12, y + 18, 8, 4, '#2e2418'); }
        else if (c.k === 'rock') { g.fillStyle = c.hp === 2 ? '#6a6a72' : '#5a5a62'; g.beginPath(); g.ellipse(x + cw / 2 + w, y + ch / 2, 11, 8, 0, 0, Math.PI * 2); g.fill(); px(g, x + 12, y + 10, 4, 2, '#8a8a92'); if (c.hp === 1) px(g, x + 10, y + 14, 12, 1, '#2a2a30'); }
      }
      if (c.x === this.cx && c.y === this.cy) { g.strokeStyle = '#e8c84a'; g.lineWidth = 1; g.strokeRect(x + 0.5, y + 0.5, cw - 1, ch - 1); }
    }
    // the rain drip: the beat
    const ph = (this.t % this.beat) / this.beat; const onb = ph < 0.16 || ph > 0.84; const dy = 44 + ph * 150; px(g, 448, 44, 1, 154, '#2a3038'); g.fillStyle = onb ? '#8ae88a' : '#8ab0d8'; g.fillRect(445, dy, 6, 6); px(g, 440, 198, 16, 2, onb ? '#8ae88a' : '#2a3038'); drawText(g, 'the drip', 448, 204, '#6a7280', { align: 'center' }); if (onb) { g.strokeStyle = 'rgba(138,232,138,0.5)'; g.strokeRect(ox - 4.5, oy - 4.5, this.cols * cw + 9, this.rows * ch + 9); }
    if (this.pop) { const x = ox + this.pop.x * cw + cw / 2, y = oy + this.pop.y * ch - 8 - (120 - this.pop.t) * 0.15; UI.panel(g, x - 50, y - 8, 100, 14, 0.95); drawText(g, this.pop.name, x, y - 4, '#e8c84a', { align: 'center' }); }
    if (this.intro > 0) mgIntro(g, ['Weeds pull in one, roots in three, rocks in two.', 'ARROWS move, E digs. Dig on the drip of the rain', 'and it counts double. Any key to start.'], 200);
    else if (this.over > 0) { UI.panel(g, W / 2 - 110, 204, 220, 22, 0.95); drawText(g, this.cleared >= this.total ? 'Down to the dirt.' : `${Math.round(100 * this.cleared / this.total)}% of it. Your chest says stop.`, W / 2, 210, '#e8c84a', { align: 'center' }); }
    else UI.drawHint(g, 'E on the drip');
  }
}
{
  const gc0 = Garden.clear;
  Garden.clear = function () {
    startMinigame('dig', (pay, res) => {
      const [frac, find, onBeat, digs] = res; gc0.call(this);
      if (!Dlg.active) return; const s = this.S();
      const extra = [];
      if (frac < 0.6) extra.push(narr('Less than you meant to. The weeds you left look like they know it.'));
      else if (frac >= 1 && onBeat >= digs * 0.6) extra.push(narr('You found the rhythm of it somewhere in the second row; the rain kept time and you kept with it. Hector, Mrs. Ortega will tell you later, dug like that.'));
      if (find) { G.flags[find.flag] = true; remember(find.mem); extra.push(narr('Under a root, something that is not a root.'), narr(find.line)); }
      Dlg.steps.splice(Dlg.steps.length - (s.cleared >= 2 ? 1 : 0), 0, ...extra);
    });
  };
  FRESH.granny = FRESH.granny || []; FRESH.granny.push(
    L_("You found his trowel. He lost that trowel in 1994 and blamed me for eleven years. Keep it. Don't tell him.", () => G.flags.hectorTrowel),
    L_("A cap from 1974. That was the year he sat out there every evening with one beer, one, and told me the beans could hear him. Maybe they could.", () => G.flags.hectorCap),
    L_("A marble. Our grandson. He's thirty-four now and he still can't find anything; that's where it went.", () => G.flags.hectorMarble));
  // the finds sit on a shelf by the shed door afterwards
  const pb0 = paintBeds; paintBeds = function (g, camX, t) { pb0(g, camX, t); if (!(G.flags.hectorTrowel || G.flags.hectorCap || G.flags.hectorMarble)) return; const x = 422 - camX; px(g, x, GROUND_Y - 22, 16, 2, '#4a3a2a'); if (G.flags.hectorTrowel) { px(g, x + 2, GROUND_Y - 32, 2, 10, '#8a7a5a'); px(g, x + 1, GROUND_Y - 26, 4, 4, '#7a7a82'); } if (G.flags.hectorCap) px(g, x + 8, GROUND_Y - 25, 3, 3, '#a86a5a'); if (G.flags.hectorMarble) px(g, x + 13, GROUND_Y - 25, 3, 3, '#6ab86a'); };
}

// ---------- THE COFFEE ----------
// Six measuring cups, one after another: grounds, grounds, water, water, milk, sugar. Stop each one at the line.
const POURS = [
  { k: 'grounds', label: 'coffee grounds', col: '#4a3020', top: '#5a3a28', speed: 0.0075, target: 0.62 },
  { k: 'grounds', label: 'coffee grounds, the second scoop', col: '#4a3020', top: '#5a3a28', speed: 0.0095, target: 0.78 },
  { k: 'water', label: 'water', col: 'rgba(120,170,220,0.75)', top: 'rgba(200,230,255,0.9)', speed: 0.014, target: 0.7 },
  { k: 'water', label: 'water, to the line', col: 'rgba(120,170,220,0.75)', top: 'rgba(200,230,255,0.9)', speed: 0.017, target: 0.86 },
  { k: 'milk', label: 'milk', col: '#e8e4d8', top: '#f8f6f0', speed: 0.011, target: 0.36 },
  { k: 'sugar', label: 'sugar', col: '#e0d8c8', top: '#f0ece0', speed: 0.006, target: 0.24 },
];
class CoffeeGame {
  start() { this.t = 0; this.intro = 180; this.over = 0; this.round = 0; this.level = 0; this.pouring = true; this.settle = 0; this.results = []; this.pay = 0; this.drops = []; this.wobble = 0; this.nudge = 0; }
  cur() { return POURS[this.round]; }
  update() {
    if (this.intro > 0) { this.intro--; if (Input.anyHit()) this.intro = 0; return; }
    if (this.over > 0) { this.over--; if (this.over === 0 || Input.hit('act')) endMinigame(this.pay, [`${this.results.filter(r => r.grade === 'perfect').length}/6 on the line`, `${this.results.filter(r => r.grade === 'over').length} spilled`]); return; }
    this.t++; const p = this.cur();
    if (this.pouring) {
      // the pour is not quite steady; water rushes, sugar trickles, the last third of the cup goes a little faster than you expect
      const wob = 1 + Math.sin(this.t * 0.11) * 0.18 + (this.level > 0.6 ? 0.12 : 0);
      this.level += p.speed * wob; if (this.t % 3 === 0) this.drops.push({ x: 240 + rnd(-3, 3), y: 92, vy: rnd(1.5, 2.5), t: 30 });
      if (Input.hit('act') || this.level >= 1.08) {
        this.pouring = false; this.settle = 70; const over = this.level > 1; const d = Math.abs(this.level - p.target);
        const grade = over ? 'over' : d < 0.03 ? 'perfect' : d < 0.07 ? 'good' : d < 0.13 ? 'ok' : 'poor'; const earn = { perfect: 6, good: 5, ok: 4, poor: 2, over: 0 }[grade];
        this.results.push({ grade, earn, level: this.level }); this.pay += earn;
        if (over) Audio.bad(); else Audio.tone(grade === 'perfect' ? 1100 : grade === 'good' ? 880 : 600, 0.08, 'square', 0.04); if (grade === 'perfect') Audio.coin();
      }
    } else { this.settle--; if (this.settle <= 0) { this.round++; if (this.round >= POURS.length) { this.over = 170; Audio.tone(660, 0.2, 'triangle', 0.03); } else { this.level = 0; this.pouring = true; } } }
    for (const d of this.drops) { d.y += d.vy; d.t--; } this.drops = this.drops.filter(d => d.t > 0 && d.y < 200);
  }
  draw(g, t) {
    mgFrame(g, "THE COFFEE - NADIA'S", `cup ${Math.min(this.round + 1, 6)}/6   pay $${this.pay}`);
    const p = this.cur() || POURS[5];
    // the counter and the urn
    px(g, 40, 200, W - 80, 30, '#5a4a3a'); px(g, 40, 200, W - 80, 2, '#7a6a5a');
    px(g, 200, 60, 80, 34, '#8a8a92'); px(g, 200, 60, 80, 2, '#b8b8c0'); px(g, 236, 94, 8, 6, '#6a6a72'); drawText(g, p.k === 'water' ? 'WATER' : p.k === 'milk' ? 'MILK' : p.k === 'sugar' ? 'SUGAR' : 'GROUNDS', 240, 72, '#2a2a30', { align: 'center' });
    // the measuring cup
    const cx = 210, cy = 110, cw = 60, chh = 88;
    px(g, cx, cy, cw, chh, 'rgba(200,220,240,0.12)'); px(g, cx, cy, 1, chh, '#b8c8d8'); px(g, cx + cw - 1, cy, 1, chh, '#b8c8d8'); px(g, cx, cy + chh - 1, cw, 1, '#b8c8d8'); px(g, cx + cw, cy + 20, 10, 3, '#b8c8d8'); px(g, cx + cw + 8, cy + 20, 3, 30, '#b8c8d8');
    for (let i = 1; i < 8; i++) px(g, cx + 2, cy + chh - Math.round(i * chh / 8), i % 2 ? 5 : 9, 1, '#8a9aa8');
    // the line
    const ty = cy + chh - Math.round(p.target * chh); px(g, cx - 12, ty, cw + 24, 1, '#e8c84a'); drawText(g, 'the line', cx - 16, ty - 3, '#e8c84a', { align: 'right' });
    // the fill
    const lv = Math.min(this.level, 1); const fh = Math.round(lv * (chh - 2)); if (fh > 0) { px(g, cx + 1, cy + chh - 1 - fh, cw - 2, fh, p.col); px(g, cx + 1, cy + chh - 1 - fh, cw - 2, 1, p.top); }
    if (this.level > 1) { for (let i = 0; i < 6; i++) px(g, cx - 4 + i * 12 + Math.sin(t + i) * 2, cy + chh + 2 + (i % 3) * 3, 6, 2, p.col); }
    for (const d of this.drops) { g.fillStyle = p.top; g.fillRect(d.x, d.y, 2, 3); }
    // the six cups so far
    for (let i = 0; i < 6; i++) { const x = 320 + (i % 3) * 36, y = 110 + Math.floor(i / 3) * 44; const r = this.results[i]; px(g, x, y, 24, 30, 'rgba(200,220,240,0.1)'); px(g, x, y, 1, 30, '#8a9aa8'); px(g, x + 23, y, 1, 30, '#8a9aa8'); px(g, x, y + 29, 24, 1, '#8a9aa8');
      const pp = POURS[i]; px(g, x - 3, y + 30 - Math.round(pp.target * 28), 30, 1, 'rgba(232,200,74,0.5)');
      if (r) { const h = Math.round(Math.min(r.level, 1) * 28); px(g, x + 1, y + 29 - h, 22, h, pp.col); drawText(g, r.grade === 'over' ? 'spill' : r.grade === 'perfect' ? '$6' : '$' + r.earn, x + 12, y + 32, r.grade === 'over' ? '#e86a6a' : r.grade === 'perfect' ? '#8ae88a' : '#c8ccd8', { align: 'center' }); }
      else if (i === this.round && !this.over) px(g, x + 8, y + 12, 8, 6, 'rgba(232,200,74,0.3)'); }
    if (!this.intro && !this.over) drawText(g, p.label, 40, 100, '#c8ccd8');
    if (!this.pouring && this.settle > 0 && this.results.length) { const r = this.results[this.results.length - 1]; drawText(g, r.grade === 'over' ? 'Over. She dumps it and hands you the next.' : r.grade === 'perfect' ? 'On the line.' : r.grade === 'good' ? 'Close enough for the morning crowd.' : r.grade === 'ok' ? 'Near enough.' : 'Nadia looks at it and says nothing.', W / 2, 236, r.grade === 'over' ? '#e86a6a' : r.grade === 'perfect' ? '#8ae88a' : '#8a92a4', { align: 'center' }); }
    if (this.intro > 0) mgIntro(g, ['Six cups: grounds, grounds, water, water, milk, sugar.', 'Each one pours on its own. Press E to stop it', 'at the yellow line. Over the top is a spill. Any key.'], 204);
    else if (this.over > 0) { UI.panel(g, W / 2 - 110, 204, 220, 22, 0.95); drawText(g, `Pot's on. $${this.pay}.`, W / 2, 210, '#e8c84a', { align: 'center' }); }
    else UI.drawHint(g, 'E to stop the pour');
  }
}
{
  const sm1 = startMinigame; startMinigame = function (kind, onDone) { if (kind === 'coffee') { MG.onDone = onDone; MG.cur = new CoffeeGame(); MG.cur.start(); G.state = 'minigame'; return; } return sm1(kind, onDone); };
  // unlocked after five dish shifts: less energy, more money, and it counts the same as a shift
  Nadia.coffee = function (free) {
    const n = C('nadia'); if (free) n.freeToday = true;
    if (!n.coffeeShown) { n.coffeeShown = true; Dlg.run([say('nadia', "Five shifts on the sink. Come around the counter. The urn's older than Sam and it has opinions; you stop the pour at the line or the whole pot's mud."), narr('She shows you once. Grounds, grounds, water, water, milk for the one regular who takes it, sugar for the other.')], () => this.coffeeGo(free)); }
    else this.coffeeGo(free);
  };
  Nadia.coffeeGo = function (free) {
    const n = C('nadia');
    startMinigame('coffee', (pay, lines) => {
      useEnergy(15); addHunger(-6); n.shifts++; n.coffeeShifts = (n.coffeeShifts || 0) + 1; remember('nadia_coffee');
      if (free) { n.freeShifts++; trust('nadia', 2); remember('nadia_free'); Dlg.run([say('nadia', "I'll remember this. I don't forget things like this."), narr(lines.join('. ') + '.')]); }
      else { addMoney(pay); Dlg.run([narr(lines.join('. ') + '.'), say('nadia', pay >= 30 ? "That's a pot. That's an actual pot. Sit down, I'm pouring you the first cup." : pay >= 20 ? "Drinkable. The morning crowd won't know the difference; the morning crowd is Walter." : "...I'll fix it. Go wash something.")]); }
    });
  };
  const nm0 = Nadia.menu; Nadia.menu = function () {
    nm0.call(this); const n = C('nadia'); if (!Menu.active || n.shifts < 5 || n.closed) return;
    const at = Menu.items.findIndex(i => /dish shift/.test(i.t)); Menu.items.splice(at >= 0 ? at + 1 : 1, 0, { t: 'Make the coffee', r: '-15 energy', disabled: () => G.energy < 12, do: () => this.coffee(false) });
    const fi = Menu.items.findIndex(i => /shift for free/.test(i.t)); if (fi >= 0) Menu.items.splice(fi + 1, 0, { t: 'Make the coffee for free', r: '-15 energy', disabled: () => G.energy < 12, do: () => this.coffee(true) });
  };
  FRESH.nadia = FRESH.nadia || []; FRESH.nadia.push(
    L_("Walter said the coffee was different. Walter has said nothing about the coffee in twenty years. I'm taking it as a compliment to you.", () => (G.chars.nadia.coffeeShifts || 0) >= 1 && !G.chars.walter.dead),
    L_("The urn's going to outlive both of us. I've made my peace with it. You stop at the line; that's the whole religion.", () => (G.chars.nadia.coffeeShifts || 0) >= 3));
}
