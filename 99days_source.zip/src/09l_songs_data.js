// ============================================================
// The songs, as data. The dashboard's Music section edits this file; keep it pure JSON between the markers.
// id, title, who (cal | sol | three), bpm, bar (beats per bar), key (MIDI note), unlock (always | theoReunited | bandNight | walterDead | day>=N | flag:NAME | never),
// chords per bar [semitones above key, "M"|"m"], melody per bar [[semitone above key (null = rest), beats], ...], lyrics [[beat, text]], inst (the mix and the sound of each part).
// ============================================================
const SONG_DATA = /*SONGS*/[
  {
    "id": "rain", "title": "Rain on Harlan", "who": "cal", "bpm": 88, "bar": 3, "key": 57, "unlock": "always",
    "chords": [[0,"m"],[0,"m"],[8,"M"],[8,"M"],[3,"M"],[3,"M"],[7,"M"],[7,"M"],[0,"m"],[0,"m"],[5,"m"],[5,"m"],[3,"M"],[7,"M"],[0,"m"],[0,"m"]],
    "melody": [
      [[12,2],[15,1]],
      [[14,2],[12,1]],
      [[12,1],[15,1],[19,1]],
      [[17,3]],
      [[15,2],[12,1]],
      [[14,2],[10,1]],
      [[11,1],[14,1],[12,1]],
      [[12,3]],
      [[19,2],[17,1]],
      [[15,2],[12,1]],
      [[14,1],[15,1],[17,1]],
      [[15,3]],
      [[12,1],[14,1],[15,1]],
      [[11,2],[14,1]],
      [[12,3]],
      [[null,3]]
    ],
    "lyrics": [
      [0,"Rain on Harlan, rain on the wire,"],
      [12,"rain on the man who sleeps by the door."],
      [24,"Nobody asked and nobody told him"],
      [36,"what all this water was for."]
    ],
    "outro": "The last chord hangs in the wet air longer than it should. A woman with a stroller has stopped. She goes on.",
    "inst": {"bass":{"on":true,"vol":0.05,"type":"sine","cutoff":2200,"attack":0.012,"octave":-1},"guitar":{"on":true,"vol":0.022,"type":"triangle","cutoff":2200,"attack":0.012,"pattern":"arp"},"melody":{"on":true,"vol":0.06,"type":"triangle","cutoff":2200,"attack":0.012,"octave":1},"cello":{"on":false,"vol":0.05,"type":"sawtooth","cutoff":500,"attack":0.12,"octave":-1},"horn":{"on":false,"vol":0.035,"type":"square","cutoff":1700,"attack":0.08,"vibrato":0.006,"mode":"long","crack":0,"octave":2}}
  },
  {
    "id": "the14", "title": "The 14", "who": "cal", "bpm": 104, "bar": 4, "key": 55, "unlock": "always",
    "chords": [[0,"M"],[0,"M"],[5,"M"],[7,"M"],[0,"M"],[9,"m"],[5,"M"],[7,"M"],[0,"M"],[4,"m"],[5,"M"],[7,"M"],[0,"M"],[0,"M"]],
    "melody": [
      [[7,1],[7,1],[9,1],[11,1]],
      [[12,2],[11,1],[9,1]],
      [[7,2],[5,1],[7,1]],
      [[9,3],[null,1]],
      [[7,1],[7,1],[9,1],[11,1]],
      [[12,2],[14,1],[12,1]],
      [[11,1],[9,1],[7,1],[5,1]],
      [[7,3],[null,1]],
      [[12,1],[12,1],[14,1],[16,1]],
      [[14,2],[12,1],[11,1]],
      [[9,1],[11,1],[12,1],[9,1]],
      [[11,2],[7,2]],
      [[7,4]],
      [[null,4]]
    ],
    "lyrics": [
      [0,"Twelve minutes, she said, you could set a watch,"],
      [16,"so she set it, and set it, and set it again."],
      [32,"The 14 got cut in the spring of the year"],
      [44,"and the old man's still waiting. Amen."]
    ],
    "outro": "He looks over at the bench when he finishes. He always does, even now.",
    "inst": {"bass":{"on":true,"vol":0.05,"type":"sine","cutoff":2200,"attack":0.012,"octave":-1},"guitar":{"on":true,"vol":0.022,"type":"triangle","cutoff":2200,"attack":0.012,"pattern":"arp"},"melody":{"on":true,"vol":0.06,"type":"triangle","cutoff":2200,"attack":0.012,"octave":1},"cello":{"on":false,"vol":0.05,"type":"sawtooth","cutoff":500,"attack":0.12,"octave":-1},"horn":{"on":false,"vol":0.035,"type":"square","cutoff":1700,"attack":0.08,"vibrato":0.006,"mode":"long","crack":0,"octave":2}}
  },
  {
    "id": "fourth", "title": "Fourth Floor", "who": "cal", "bpm": 108, "bar": 4, "key": 50, "unlock": "always",
    "chords": [[0,"M"],[9,"m"],[5,"M"],[7,"M"],[0,"M"],[9,"m"],[5,"M"],[7,"M"],[9,"m"],[5,"M"],[0,"M"],[7,"M"],[0,"M"],[0,"M"]],
    "melody": [
      [[0,1],[4,1],[7,1],[4,1]],
      [[9,2],[7,1],[4,1]],
      [[5,1],[7,1],[9,1],[7,1]],
      [[7,3],[null,1]],
      [[0,1],[4,1],[7,1],[9,1]],
      [[12,2],[9,1],[7,1]],
      [[5,1],[4,1],[2,1],[4,1]],
      [[0,3],[null,1]],
      [[12,1],[12,1],[11,1],[9,1]],
      [[9,2],[7,2]],
      [[4,1],[7,1],[9,1],[7,1]],
      [[11,2],[7,1],[4,1]],
      [[0,4]],
      [[null,4]]
    ],
    "lyrics": [
      [0,"Fourth floor, thin walls, a kettle at six,"],
      [16,"a nurse and a cough and a lock that sticks."],
      [32,"Two knocks means I'm here, two knocks means I know."],
      [44,"Fourth floor. Thin walls. Nobody has to say so."]
    ],
    "outro": "Somebody on a fire escape above the laundry claps twice. He does not look up, but he plays the last chord again for them.",
    "inst": {"bass":{"on":true,"vol":0.05,"type":"sine","cutoff":2200,"attack":0.012,"octave":-1},"guitar":{"on":true,"vol":0.022,"type":"triangle","cutoff":2200,"attack":0.012,"pattern":"arp"},"melody":{"on":true,"vol":0.06,"type":"triangle","cutoff":2200,"attack":0.012,"octave":1},"cello":{"on":false,"vol":0.05,"type":"sawtooth","cutoff":500,"attack":0.12,"octave":-1},"horn":{"on":false,"vol":0.035,"type":"square","cutoff":1700,"attack":0.08,"vibrato":0.006,"mode":"long","crack":0,"octave":2}}
  },
  {
    "id": "1962", "title": "Something From 1962", "who": "cal", "bpm": 104, "bar": 4, "key": 52, "unlock": "always",
    "chords": [[0,"M"],[4,"m"],[9,"m"],[7,"M"],[0,"M"],[4,"m"],[5,"M"],[7,"M"],[9,"m"],[4,"m"],[5,"M"],[7,"M"],[0,"M"],[0,"M"]],
    "melody": [
      [[4,1],[7,1],[11,2]],
      [[9,1],[7,1],[4,2]],
      [[5,1],[7,1],[9,1],[11,1]],
      [[7,3],[null,1]],
      [[4,1],[7,1],[11,2]],
      [[12,1],[11,1],[9,2]],
      [[7,1],[9,1],[11,1],[12,1]],
      [[11,3],[null,1]],
      [[12,1],[11,1],[9,1],[7,1]],
      [[9,2],[7,1],[4,1]],
      [[5,1],[4,1],[2,1],[4,1]],
      [[7,2],[4,2]],
      [[0,4]],
      [[null,4]]
    ],
    "lyrics": [
      [0,"He asked for something from sixty-two;"],
      [16,"I played it wrong and he said so, too."],
      [32,"I've got it now, I've got it right,"],
      [44,"and the bench is empty tonight."]
    ],
    "outro": "He did not use to play that one. He plays it every day now, the right way, for a bench.",
    "alt": {"when":"walterDead","title":"Something From 1962","lyrics":[[0,"He asked for something from sixty-two;"],[16,"I played it wrong and he said so, too."],[32,"I'll get it right if it takes all year,"],[44,"and he'll be on that bench to hear."]],"outro":"The old man on the bench lifts his cane an inch. From Walter, that is a standing ovation."},
    "inst": {"bass":{"on":true,"vol":0.05,"type":"sine","cutoff":2200,"attack":0.012,"octave":-1},"guitar":{"on":true,"vol":0.022,"type":"triangle","cutoff":2200,"attack":0.012,"pattern":"arp"},"melody":{"on":true,"vol":0.06,"type":"triangle","cutoff":2200,"attack":0.012,"octave":1},"cello":{"on":false,"vol":0.05,"type":"sawtooth","cutoff":500,"attack":0.12,"octave":-1},"horn":{"on":false,"vol":0.035,"type":"square","cutoff":1700,"attack":0.08,"vibrato":0.006,"mode":"long","crack":0,"octave":2}}
  },
  {
    "id": "sixth", "title": "Sixth Street", "who": "cal", "bpm": 100, "bar": 4, "key": 57, "unlock": "theoReunited",
    "chords": [[0,"m"],[8,"M"],[3,"M"],[10,"M"],[0,"m"],[8,"M"],[3,"M"],[10,"M"],[5,"m"],[3,"M"],[8,"M"],[10,"M"],[0,"m"],[0,"m"]],
    "melody": [
      [[12,1],[12,1],[15,1],[17,1]],
      [[15,2],[12,1],[10,1]],
      [[12,1],[15,1],[17,1],[19,1]],
      [[17,3],[null,1]],
      [[12,1],[12,1],[15,1],[17,1]],
      [[19,2],[17,1],[15,1]],
      [[12,1],[10,1],[8,1],[10,1]],
      [[12,3],[null,1]],
      [[20,1],[19,1],[17,1],[15,1]],
      [[17,2],[15,1],[12,1]],
      [[15,1],[17,1],[19,1],[17,1]],
      [[15,2],[10,2]],
      [[12,4]],
      [[null,4]]
    ],
    "lyrics": [
      [0,"Bad couch on Sixth, a foot too short,"],
      [16,"a kid who sleeps like he's standing guard."],
      [32,"I wrote him a bus he's never been on"],
      [44,"and he rode it all the way home."]
    ],
    "outro": "Theo stands next to him for the whole thing with his hood down, which is the first time you have seen his whole face in daylight. When it ends he says \"the bus part's wrong\" and Cal says \"I know\" and neither of them means it.",
    "inst": {"bass":{"on":true,"vol":0.05,"type":"sine","cutoff":2200,"attack":0.012,"octave":-1},"guitar":{"on":true,"vol":0.022,"type":"triangle","cutoff":2200,"attack":0.012,"pattern":"arp"},"melody":{"on":true,"vol":0.06,"type":"triangle","cutoff":2200,"attack":0.012,"octave":1},"cello":{"on":false,"vol":0.05,"type":"sawtooth","cutoff":500,"attack":0.12,"octave":-1},"horn":{"on":false,"vol":0.035,"type":"square","cutoff":1700,"attack":0.08,"vibrato":0.006,"mode":"long","crack":0,"octave":2}}
  },
  {
    "id": "three", "title": "Under the Shelter", "who": "three", "bpm": 92, "bar": 4, "key": 48, "unlock": "bandNight", "band": true,
    "chords": [[0,"M"],[5,"M"],[9,"m"],[7,"M"],[0,"M"],[5,"M"],[2,"m"],[7,"M"],[9,"m"],[4,"m"],[5,"M"],[7,"M"],[0,"M"],[0,"M"]],
    "melody": [
      [[7,2],[4,1],[5,1]],
      [[7,3],[9,1]],
      [[12,2],[9,1],[7,1]],
      [[7,3],[null,1]],
      [[4,1],[7,1],[12,2]],
      [[11,2],[9,1],[7,1]],
      [[5,2],[7,1],[9,1]],
      [[7,3],[null,1]],
      [[12,1],[12,1],[14,1],[16,1]],
      [[14,2],[12,2]],
      [[9,1],[12,1],[14,1],[12,1]],
      [[11,2],[7,2]],
      [[12,4]],
      [[null,4]]
    ],
    "lyrics": [
      [0,"(the cello, under everything)"],
      [16,"(the horn, cracking once and then not)"],
      [32,"(nobody sings; nobody needs to)"]
    ],
    "outro": "Eleven minutes. When it ends nobody claps, because the street does not know that it is allowed to, and then Nadia does, once, with the towel still over her shoulder, and then it is allowed.",
    "inst": {"bass":{"on":true,"vol":0.05,"type":"sine","cutoff":2200,"attack":0.012,"octave":-1},"guitar":{"on":true,"vol":0.022,"type":"triangle","cutoff":2200,"attack":0.012,"pattern":"arp"},"melody":{"on":true,"vol":0.06,"type":"triangle","cutoff":2200,"attack":0.012,"octave":1},"cello":{"on":true,"vol":0.05,"type":"sawtooth","cutoff":500,"attack":0.12,"octave":-1},"horn":{"on":true,"vol":0.035,"type":"square","cutoff":1800,"attack":0.12,"vibrato":0,"mode":"long","crack":0,"octave":2}}
  },
  {
    "id": "sol1994", "title": "1994", "who": "sol", "bpm": 66, "bar": 4, "key": 55, "unlock": "never", "solo": true, "hint": "let him stop",
    "chords": [[0,"M"],[9,"m"],[5,"M"],[7,"M"],[0,"M"],[9,"m"],[5,"M"],[7,"M"],[0,"M"],[0,"M"]],
    "melody": [
      [[7,1],[12,1],[16,2]],
      [[14,2],[12,1],[9,1]],
      [[5,1],[9,1],[12,2]],
      [[11,3],[null,1]],
      [[7,1],[12,1],[16,1],[19,1]],
      [[17,2],[16,1],[14,1]],
      [[12,2],[9,1],[7,1]],
      [[11,2],[14,2]],
      [[12,4]],
      [[null,4]]
    ],
    "lyrics": [
      [0,"(four notes, cracked, thin, exactly wrong)"],
      [4,"(then the fifth, which is nearly music)"],
      [16,"(the bell of it is dented; the note is not)"],
      [30,"(he holds the last one longer than he has wind for)"]
    ],
    "outro": "",
    "early": "He stops when you look away. He was not playing for you, particularly. He was playing for 1994.",
    "inst": {"bass":{"on":false,"vol":0.05,"type":"sine","cutoff":2200,"attack":0.012,"octave":-1},"guitar":{"on":false,"vol":0.022,"type":"triangle","cutoff":2200,"attack":0.012,"pattern":"arp"},"melody":{"on":false,"vol":0.06,"type":"triangle","cutoff":2200,"attack":0.012,"octave":1},"cello":{"on":false,"vol":0.05,"type":"sawtooth","cutoff":500,"attack":0.12,"octave":-1},"horn":{"on":true,"vol":0.075,"type":"square","cutoff":1700,"attack":0.08,"vibrato":0.006,"mode":"all","crack":4,"octave":1}}
  }
]/*END*/;
