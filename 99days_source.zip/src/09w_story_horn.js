// ============================================================
// Sol's trumpet: one song, no band. Four cracked notes and then the thing itself.
// ============================================================
const SOL_SONG = {
  id: 'sol1994', title: '1994', bpm: 66, bar: 4, key: 55, solo: true, who: 'sol', hint: 'let him stop',
  chords: [[0, 'M'], [9, 'm'], [5, 'M'], [7, 'M'], [0, 'M'], [9, 'm'], [5, 'M'], [7, 'M'], [0, 'M'], [0, 'M']],
  melody: [[[7, 1], [12, 1], [16, 2]], [[14, 2], [12, 1], [9, 1]], [[5, 1], [9, 1], [12, 2]], [[11, 3], [null, 1]],
    [[7, 1], [12, 1], [16, 1], [19, 1]], [[17, 2], [16, 1], [14, 1]], [[12, 2], [9, 1], [7, 1]], [[11, 2], [14, 2]], [[12, 4]], [[null, 4]]],
  lyrics: [[0, '(four notes, cracked, thin, exactly wrong)'], [4, '(then the fifth, which is nearly music)'], [16, '(the bell of it is dented; the note is not)'], [30, '(he holds the last one longer than he has wind for)']],
  early: 'He stops when you look away. He was not playing for you, particularly. He was playing for 1994.',
  outro: ''
};
// the horn: square wave under a lowpass, a little vibrato once it settles, a crack on the first four notes
Song.solo = function (spec, t0, beat) {
  const c = Audio.ctx; const muted = spec.who === 'sol' && G.chars.sol && G.chars.sol.mute;
  const horn = (m, t, len, vol, crack) => {
    const o = c.createOscillator(), g = c.createGain(), fl = c.createBiquadFilter(); o.type = 'square';
    const hz = midiHz(m) * (crack ? (1 + (crack % 2 ? -0.03 : 0.025)) : 1); o.frequency.setValueAtTime(hz * 0.985, t); o.frequency.exponentialRampToValueAtTime(hz, t + 0.07);
    fl.type = muted ? 'bandpass' : 'lowpass'; fl.frequency.value = muted ? 1400 : (crack ? 900 : 1700); if (muted) fl.Q.value = 1.4;
    if (!crack) { const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = 5.2; lg.gain.value = hz * 0.006; lfo.connect(lg); lg.connect(o.frequency); lfo.start(t + 0.25); lfo.stop(t + len + 0.1); this.nodes.push(lfo); }
    const v = vol * (muted ? 0.6 : 1) * (crack ? 0.55 : 1); const L = crack ? len * 0.55 : len;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + (crack ? 0.03 : 0.08)); g.gain.setValueAtTime(v, t + L * 0.75); g.gain.exponentialRampToValueAtTime(0.0001, t + L);
    o.connect(fl); fl.connect(g); g.connect(Audio.master); o.start(t); o.stop(t + L + 0.05); this.nodes.push(o, g);
  };
  let tm = t0, n = 0;
  spec.melody.forEach(bar => { bar.forEach(([note, b]) => { if (note !== null) { n++; horn(spec.key + 12 + note, tm, b * beat * 0.92, 0.075, n <= 4 ? n : 0); } tm += b * beat; }); });
};
{
  Pawn.play = function () {
    const s = this.S(); if (!talkEnergy(3)) return; const again = s.played; s.played = true; s.plays = (s.plays || 0) + 1; remember('sol_played');
    SOL_SONG.after = (early) => {
      if (early) { Dlg.run([narr(SOL_SONG.early)]); return; }
      Dlg.run([say('sol', again ? "That's it. That's all of it, again." : "That's it. That's all the wind I've got."), narr(s.mute ? 'He takes the mute out of the bell and puts them both in the case. He does not lock the case.' : 'He puts it back in the case. He does not lock the case.'), { fn: () => trust('sol', again ? 1 : 2) }]);
    };
    const open = again ? [say('sol', "Again. ...Once more. Don't make it a thing."), narr(s.mute ? 'The mute goes in the bell. The clocks do not mind.' : 'He unlocks the case.')] :
      [say('sol', "You want me to play it."), you("Once."), say('sol', "..."), narr('He unlocks the case. The trumpet is dull brass, a dent in the bell. He puts it to his mouth like a man picking up a phone he expects bad news on.')];
    Dlg.run(open.concat([{ fn: () => { Dlg.steps.length = Dlg.i; setTimeout(() => Song.play(SOL_SONG), 80); } }]));
  };
  const pm3 = Pawn.menu; Pawn.menu = function () {
    pm3.call(this); const s = Pawn.S(); if (!Menu.active) return;
    if (s.played && s.trumpet && !s.cold && (s.mute || s.trust >= 5) && !Menu.items.some(i => /play it/.test(i.t))) Menu.items.splice(Menu.items.length - 1, 0, { t: 'Ask him to play it again', r: '-3 energy', do: () => Pawn.play() });
  };
}
