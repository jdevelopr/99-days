// ============================================================
// Sol's trumpet: one song, no band. Four cracked notes and then the thing itself.
// ============================================================
// SOL_SONG ('1994', solo: true) lives in 09l_songs_data.js; the horn itself is in 09l_synth.js
{
  Pawn.play = function () {
    const s = this.S(); if (!talkEnergy(3)) return; const again = s.played; s.played = true; s.plays = (s.plays || 0) + 1; remember('sol_played');
    SOL_SONG.after = (early) => {
      if (early) { Dlg.run([narr(SOL_SONG.early)]); return; }
      Dlg.run([say('sol', again ? "That's it. That's all of it, again." : "That's it. That's all the wind I've got."), narr(s.mute ? 'He takes the mute out of the bell and puts them both in the case. He does not lock the case.' : 'He puts it back in the case. He does not lock the case.'), { fn: () => trust('sol', again ? 1 : 2) }]);
    };
    const open = again ? [say('sol', "Again. ...Once more. Don't make it a thing."), narr(s.mute ? 'The mute goes in the bell. The clocks do not mind.' : 'He unlocks the case.')] :
      [say('sol', "You want me to play it."), you("Once."), say('sol', "..."), narr('He unlocks the case. The trumpet is dull brass, a dent in the bell. He puts it to his mouth like a man picking up a phone he expects bad news on.')];
    Dlg.run(open.concat([{ fn: () => { Dlg.steps.length = Dlg.i; setTimeout(() => Song.play(SOL_SONG), 80); } }]));
  };
  const pm3 = Pawn.menu; Pawn.menu = function () {
    pm3.call(this); const s = Pawn.S(); if (!Menu.active) return;
    if (s.played && s.trumpet && !s.cold && (s.mute || s.trust >= 5) && !Menu.items.some(i => /play it/.test(i.t))) Menu.items.splice(Menu.items.length - 1, 0, { t: 'Ask him to play it again', r: '-3 energy', do: () => Pawn.play() });
  };
}
