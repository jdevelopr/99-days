// ============================================================
// Amos, if nobody speaks to him: gone on day 14. Flowers on the cardboard that wilt over a week; then the cardboard is in the dumpster.
// ============================================================
{
  const ad = Amos.daily; Amos.daily = function () {
    const a = G.chars.amos;
    if (!a.met && !a.talked && !a.fed && !a.cash && !a.dead && !a.gone && G.day >= 14) { a.gone = true; a.dead = true; a.goneDay = G.day; G.flags.amosGone = true; G.pendingStreet = 'amosGone'; remember('amos_unmet_gone'); return; }
    return ad.call(this);
  };
  // the mat after: flowers, wilting; then the corner of the cardboard in the dumpster
  const dp2 = drawPuddles; drawPuddles = function (g, ents, camX, pal, t) {
    const a = G.chars && G.chars.amos;
    if (a && a.dead && G.flags.amosGone) {
      const days = G.day - (a.goneDay || G.day); const x0 = 220 - camX;
      if (x0 > -60 && x0 < W + 60) {
        if (days >= 7) {
          const _ = 0;
          if (days === 7 && !G.flags.amosMatSeen && G.scene === 'street' && Math.abs(G.px - 270) < 80) { G.flags.amosMatSeen = true; setTimeout(() => { if (!Dlg.active && G.state === 'play') Dlg.run([narr('The flowers are gone. So is the cardboard. A corner of it sticks out of the dumpster by the stoop, the side he wrote on, the word you never read.')]); }, 300); }
        }
      }
    }
    dp2(g, ents, camX, pal, t);
  };
  // the corner of the cardboard sticks out of the dumpster (drawn after the dumpster itself)
  const dr = drawRain; drawRain = function (g, t, camX, clip) {
    if (G.scene === 'street' && !clip) { const a = G.chars && G.chars.amos; const days = a ? G.day - (a.goneDay || G.day) : 0;
      if (a && a.dead && G.flags.amosGone && days < 7) { const x0 = 220 - camX; if (x0 > -60 && x0 < W + 60) {
          const w = clamp(days / 7, 0, 1); const stem = w < 0.5 ? '#3a7a34' : '#7a7a3a', head = w < 0.3 ? '#e8b83a' : w < 0.6 ? '#c8a04a' : '#8a7a4a'; const droop = Math.round(w * 6);
          px(g, x0 + 4, FEET_Y - 4, 16, 3, '#e8e0d0');
          for (let i = 0; i < 5; i++) { const fx = x0 + 8 + i * 4; const h = 10 - Math.round(w * 4); px(g, fx, FEET_Y - 1 - h + droop, 1, h, stem); px(g, fx - 1 + (i % 2 ? Math.round(droop / 2) : 0), FEET_Y - 2 - h + droop, 3, 3, i === 2 ? (w < 0.6 ? '#d84a3a' : '#7a3a2a') : head); }
          px(g, x0 + 24, FEET_Y - 8, 5, 8, 'rgba(220,230,240,0.5)'); px(g, x0 + 25, FEET_Y - 7, 3, 3, w < 0.15 ? '#f8e88a' : '#c8c0b0'); } }
      if (a && a.dead && G.flags.amosGone && days >= 7) { const dx = 270 - camX; if (dx > -60 && dx < W) { px(g, dx + 28, FEET_Y - 33, 12, 7, '#b8a070'); px(g, dx + 28, FEET_Y - 33, 12, 1, '#d0b888'); px(g, dx + 31, FEET_Y - 30, 6, 1, '#8a7a5a'); px(g, dx + 30, FEET_Y - 28, 3, 1, '#8a7a5a'); } } }
    return dr(g, t, camX, clip);
  };
}
