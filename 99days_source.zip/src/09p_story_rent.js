// ============================================================
// Rent. A hundred a week, Mondays, under the super's door. Miss three and there is a padlock on 412.
// ============================================================
const RENT = 100;
const Rent = {
  init() { return { nextDay: 8, owed: 0, missed: 0, paid: 0, lockedOut: false, lockedDay: 0, notes: 0, reminded: 0 }; },
  S() { if (!G.rent) G.rent = this.init(); return G.rent; },
  active() { return G.flags.house !== 'mine' && !G.flags.left412; },
  // Monday morning, before anything else
  wake() {
    const r = this.S(); const d = G.day; if (!this.active()) return false;
    if (d === r.nextDay - 1 && r.reminded !== d && r.owed === 0) { r.reminded = d; UI.toast(`Rent tomorrow. $${RENT}.`, '#e8c84a'); }
    if (d < r.nextDay) return false;
    r.nextDay = d + 7; const due = RENT + r.owed;
    if (G.money >= due) {
      const back = r.owed; r.owed = 0; addMoney(-due); r.paid++;
      if (r.lockedOut) { r.lockedOut = false; r.missed = 0; remember('rent_unlocked'); Dlg.run([narr(`${due} dollars in an envelope under the super's door. He comes up himself with the bolt cutters and does not say anything, which from Morrow is an apology.`), narr('412. The crack in the ceiling. You had not expected to miss it.')]); return true; }
      if (back > 0) { r.missed = 0; Dlg.run([narr(`${due} dollars under the super's door: this week and the weeks you owed.`), { fn: () => { Rent.S().noteDay = G.day; } }]); return true; }
      if (r.paid === 1) { Dlg.run([narr(`Monday. A hundred dollars in an envelope, under the super's door on the first floor. He does not answer the knock.`)]); return true; }
      UI.toast(`Rent: -$${RENT}`, '#e88a6a'); return false;
    }
    // cannot pay
    r.owed += RENT; r.missed++; r.notes++; remember('rent_missed');
    if (r.missed >= 3) { r.lockedOut = true; r.lockedDay = d; remember('rent_locked'); Dlg.run([narr(`A padlock on 412, and a notice with the building's name on it and yours. Three weeks. ${r.owed} dollars.`), narr('Your things are inside. The super will let you at them when the envelope is full, and not before; he says so through the door of the first-floor office without opening it.'), narr(G.chars.amos.room ? 'Amos has a chair. He says the chair is yours for as long as it takes, and he means the floor next to it too.' : G.chars.walter.met && !G.chars.walter.dead ? 'There is a bench at the bus stop and an old man who will not ask.' : 'There is a bench at the bus stop.')]); return true; }
    Dlg.run([narr(r.missed === 1 ? `Monday. You do not have it. A note under the door by noon, block capitals on the back of an envelope: RENT. - M.` : `Monday again, and again you do not have it. The note this time is longer: TWO WEEKS. I HAVE BEEN PATIENT. ONE MORE AND THE LOCK GOES ON. - MORROW.`), narr(`You owe ${r.owed} dollars. It is paid the way rent is paid: an envelope, under his door, whenever you have it.`)]); return true;
  },
  payItem() {
    const r = this.S(); if (!this.active() || r.owed <= 0) return null;
    return { t: 'Pay the rent you owe', r: `$${r.owed}`, disabled: () => G.money < r.owed, do: () => this.pay() };
  },
  pay() {
    const r = this.S(); const due = r.owed; if (!spend(due)) return; r.owed = 0; r.missed = 0; remember('rent_caught_up');
    if (r.lockedOut) { r.lockedOut = false; Dlg.run([narr(`${due} dollars under the office door. The bolt cutters come up the stairs behind you. 412, again.`)]); }
    else Dlg.run([narr(`${due} dollars under the super's door. A note comes back: PAID. - M.`)]);
  },
  hud(g) {
    const r = this.S(); if (!this.active() || r.owed <= 0) return;
    drawText(g, r.lockedOut ? `LOCKED OUT  owe $${r.owed}` : `RENT OWED $${r.owed}`, 10, G.flags.cureKnown || G.flags.nanoPaid || G.flags.nanoKnown ? 72 : 58, '#e86a6a');
  },
  endingLine() {
    const r = this.S(); if (!r) return null;
    if (r.lockedOut) return { name: 'Harlan Arms', line: `Padlocked on day ${r.lockedDay}, owing ${r.owed} dollars. Morrow keeps the notice on his desk. He has not thrown it away.`, bad: true };
    if (r.notes > 0 || r.owed > 0) return { name: 'Harlan Arms', line: `${r.paid} weeks of rent under the super's door${r.owed ? `, and ${r.owed} dollars still owed` : ', and every missed week paid back'}.` };
    return null;
  }
};
{
  const tm0 = tableMenu; tableMenu = function () { tm0(); const it = Rent.payItem(); if (it && Menu.active) Menu.items.splice(Menu.items.length - 1, 0, it); };
  const hd2 = hallDoor; hallDoor = function (d) {
    if (d.to === 'apartment' && Rent.S().lockedOut) { const it = Rent.payItem(); Menu.open('412', [it, { t: 'Leave', do: () => { } }], { sub: `A padlock, and a notice with your name on it. $${Rent.S().owed}.` }); return; }
    return hd2(d);
  };
  const bel4 = buildEndingList; buildEndingList = function () { const out = bel4(); const rl = Rent.endingLine(); if (rl) out.push(rl); return out; };
}
