// ============================================================
// The first floor: mailboxes, the board, the super's window. Morrow, who writes everything in block capitals and says almost nothing.
// ============================================================
SPECS.morrow = { skin: '#d8b8a0', hair: '#8a8a8a', hairStyle: 'thin', shirt: '#6a5a4a', pants: '#3a3a3a', shoes: '#2a2420', glasses: true, old: true, vest: '#4a3a30' };
SPEAKERS.morrow = { name: 'Morrow', color: '#b8b0a0', spec: 'morrow' };

INTERIORS.lobby = {
  id: 'lobby', outdoor: false, floorY: FEET_Y, x0: 60, x1: 420, ceil: CEIL_Y, ambient: [100, 92, 84],
  lamp: { x: 200, y: CEIL_Y + 18 }, window: { x: 92, y: 150, w: 18, h: 30 },
  doors: [
    { x: 62, w: 22, to: 'street', label: 'Street', at: 'home' },
    { x: 244, w: 20, to: null, label: "Super's office", office: true },
    { x: 322, w: 20, to: 'hall', label: 'Stairs', lobbyStairs: true },
    { x: 372, w: 32, to: 'hall', label: 'Elevator', lobbyElev: true },
  ],
  spawnX: 100, spawnDir: 1, spawns: { street: 100, elevator: 384, stairs: 336 },
  spots: { boxes: 130, board: 190, office: 272, stairs: 332, elevator: 388 },
  paint(g) {
    const I = this; paintRoom(g, I, '#4a4238', '#5a5048', gg => { for (let y = GROUND_Y; y < 252; y += 6) for (let x = I.x0; x < I.x1; x += 12) if (((x - I.x0) / 12 + (y - GROUND_Y) / 6) % 2 === 0) px(gg, x, y, 12, 6, 'rgba(0,0,0,0.12)'); });
    // wainscot
    px(g, I.x0, GROUND_Y - 30, I.x1 - I.x0, 26, '#3a3028'); px(g, I.x0, GROUND_Y - 30, I.x1 - I.x0, 1, '#5a4a3a'); for (let x = I.x0 + 8; x < I.x1; x += 16) px(g, x, GROUND_Y - 28, 1, 22, 'rgba(0,0,0,0.15)');
    // the street door, glass, with the building's name backwards on it
    fDoor(g, 62, GROUND_Y, '#3a2a24', { glass: true }); fWindow(g, this.window.x, this.window.y, this.window.w, this.window.h, '#2a2a30');
    // mailboxes: brass, four by six, one with a name
    px(g, 112, CEIL_Y + 12, 40, 44, '#1a1418'); for (let r = 0; r < 6; r++) for (let c = 0; c < 4; c++) { const bx = 114 + c * 9, by = CEIL_Y + 14 + r * 7; px(g, bx, by, 8, 6, '#a8884a'); px(g, bx, by, 8, 1, '#c8a850'); px(g, bx + 5, by + 2, 2, 2, '#3a3a40'); }
    px(g, 114 + 3 * 9, CEIL_Y + 14 + 3 * 7, 8, 6, '#c8a850'); px(g, 115 + 3 * 9, CEIL_Y + 16 + 3 * 7, 6, 2, '#2a2a30');   // 412
    // the board: cork in a frame
    px(g, 158, CEIL_Y + 8, 70, 46, '#3a2a1a'); px(g, 160, CEIL_Y + 10, 66, 42, '#a8804a'); for (let y = CEIL_Y + 12; y < CEIL_Y + 50; y += 3) for (let x = 162; x < 224; x += 4) if ((x + y) % 7 === 0) px(g, x, y, 1, 1, 'rgba(0,0,0,0.12)');
    px(g, 170, CEIL_Y + 2, 46, 6, '#2a2a30'); drawText(g, 'NOTICES', 193, CEIL_Y + 3, '#d8d0b8', { align: 'center' });
    // the super's office: a door with a frosted light, and beside it a window with a counter
    fDoor(g, 244, GROUND_Y, '#4a3a2a', { frame: '#1a1418' }); px(g, 247, GROUND_Y - 40, 14, 12, '#c8c8b0'); px(g, 248, GROUND_Y - 39, 12, 10, '#d8d8c0');
    px(g, 266, CEIL_Y + 10, 44, 36, '#1a1418'); px(g, 268, CEIL_Y + 12, 40, 32, '#2a2a30'); for (let y = CEIL_Y + 12; y < CEIL_Y + 44; y += 4) px(g, 268, y, 40, 1, 'rgba(0,0,0,0.25)');  // the window with the grille
    fCounter(g, 262, 314, '#6a5a4a', '#3a2e26', {}); px(g, 268, COUNTER_TOP - 6, 14, 6, '#e8e0d0'); px(g, 270, COUNTER_TOP - 5, 10, 1, '#8a8a92'); px(g, 270, COUNTER_TOP - 3, 8, 1, '#8a8a92');  // the pad
    px(g, 296, COUNTER_TOP - 5, 8, 5, '#3a3a44'); px(g, 300, COUNTER_TOP - 8, 2, 3, '#8a8a92');   // a bell nobody rings
    // radiator, the dead plant, the stairs, the elevator
    fRadiator(g, 66 + 30, GROUND_Y, 18); px(g, 232, GROUND_Y - 22, 8, 22, '#5a4a3a'); px(g, 230, GROUND_Y - 30, 12, 9, '#4a5a3a'); px(g, 233, GROUND_Y - 34, 6, 5, '#6a6a3a');
    px(g, 318, CEIL_Y, 40, GROUND_Y - CEIL_Y, '#2a2226'); for (let i = 0; i < 7; i++) px(g, 322 + i * 3, GROUND_Y - 4 - i * 6, 32 - i * 3, 3, '#3a3038'); px(g, 320, CEIL_Y + 6, 36, 9, '#2a2226'); drawText(g, 'STAIRS', 338, CEIL_Y + 7, '#d8d0b8', { align: 'center' });
    px(g, 372, GROUND_Y - 44, 32, 44, '#8a7a4a'); px(g, 372, GROUND_Y - 44, 32, 1, '#c8b070'); px(g, 387, GROUND_Y - 44, 2, 44, '#3a2a1a'); px(g, 372, GROUND_Y - 46, 32, 2, '#3a3a44');
    px(g, 376, GROUND_Y - 56, 24, 8, '#1a1a20'); for (let i = 0; i < 4; i++) px(g, 379 + i * 6, GROUND_Y - 54, 3, 4, i === 0 ? '#e8b84a' : '#3a3a44');
    px(g, 362, GROUND_Y - 30, 4, 6, '#8a7a4a'); px(g, 363, GROUND_Y - 29, 2, 2, '#e8b84a');
    fBulb(g, this.lamp.x, CEIL_Y, 18);
  },
  dynamic(g, t) {
    // the papers on the board, as many as there are notices; the office light
    const N = Lobby.notices(); const R = seeded(N.length * 13 + 5);
    for (let i = 0; i < Math.min(N.length, 10); i++) { const x = 163 + (i % 5) * 12 + Math.floor(R() * 3), y = CEIL_Y + 13 + Math.floor(i / 5) * 19 + Math.floor(R() * 3); const c = N[i].col || '#e8e0d0'; px(g, x, y, 10, 14, c); px(g, x + 4, y - 1, 2, 2, '#c83a3a'); for (let k = 0; k < 4; k++) px(g, x + 2, y + 3 + k * 3, 6 - (k % 2) * 2, 1, 'rgba(0,0,0,0.35)'); }
    if (Morrow.here()) { px(g, 269, CEIL_Y + 13, 38, 30, `rgba(255,220,150,${0.10 + 0.02 * Math.sin(t * 0.03)})`); }
    if (G.elevatorBroken) { px(g, 376, GROUND_Y - 34, 24, 12, '#e8e0c8'); drawText(g, 'OUT OF', 388, GROUND_Y - 33, '#a83030', { align: 'center' }); px(g, 378, GROUND_Y - 25, 20, 1, '#a83030'); }
  },
  fg(g) { }
};

const Morrow = {
  init() { return { met: false, talks: 0, trust: 0, radiator: false, radiatorDay: 0, drawer: false, asked: false, answer: null, padlock: false, paidHere: 0, seenLobby: false }; },
  S() { if (!G.chars.morrow) G.chars.morrow = this.init(); return G.chars.morrow; },
  here() { return G.tod > 0.04 && G.tod < 0.9; },
  menu() {
    const m = this.S(); const items = [{ t: 'Talk', r: '-2 energy', do: () => this.talk() }];
    const rp = Rent.payItem(); if (rp) items.push(rp);
    if (Rent.active() && Rent.S().owed === 0 && G.day < 92) items.push({ t: "Pay next week's rent now", r: `$${RENT}`, disabled: () => G.money < RENT, do: () => { if (!spend(RENT)) return; const r = Rent.S(); r.nextDay += 7; r.paid++; m.paidHere++; remember('rent_early'); Dlg.run([narr('A hundred dollars through the grille. He writes it in the book, and the date, and turns the book so you can see it.'), say('morrow', "PAID THRU " + CAL.short(Rent.S().nextDay - 1) + ".")]); } });
    if (m.met && !m.radiator && G.day >= 2) items.push({ t: 'Ask about the heat', do: () => this.radiator() });
    if (m.met && m.talks >= 3 && !m.drawer) items.push({ t: 'Ask about the drawer', do: () => this.drawer() });
    items.push({ t: 'Leave', do: () => { } });
    Menu.open(m.met ? 'Morrow' : 'The super', items, { sub: m.met ? 'A pad, a pen, a book. He looks at you over the glasses.' : 'A man behind a grille with a pad in front of him. He does not say anything. He picks up the pen.' });
  },
  talk() {
    const m = this.S(); if (!talkEnergy(2)) return; m.talks++; const L = [];
    if (!m.met) { m.met = true; clearPortrait('morrow'); remember('morrow_met'); L.push(narr('He looks at you for a long moment, the way he must look at everybody who comes to the window, which is nobody. Then he writes on the pad and turns it around.'), say('morrow', "412."), you("Yes."), say('morrow', "RENT MONDAYS. I KNOW YOU KNOW."), narr('He tears the page off and puts it in a drawer. There are a lot of pages in the drawer.'), say('morrow', "MORROW. SUPER. TWENTY-TWO YEARS. IF THE HEAT GOES, KNOCK. I DON'T ANSWER, BUT I HEAR IT.")); }
    else if (m.talks === 2) L.push(say('morrow', "I DON'T TALK. THROAT. 1998. IT'S NOT A SECRET, IT'S JUST NOT A CONVERSATION."), narr('He shrugs, which is a whole sentence.'));
    else if (m.talks === 3) L.push(say('morrow', "THE ELEVATOR IS OLDER THAN ME. THE BOILER IS OLDER THAN THE ELEVATOR. THE BUILDING WAS HERE BEFORE THE STREET."), say('morrow', "I KEEP IT STANDING. THAT'S THE JOB. NOBODY NOTICES A BUILDING THAT'S STANDING."));
    else if (m.talks === 5 && G.chars.amos.met) L.push(say('morrow', G.chars.amos.room ? "THE MAN IN THE BASEMENT. I KNOW. I'VE KNOWN SINCE THE FIRST NIGHT. THE BOILER ROOM HAS A DOOR THAT DOESN'T LOCK BECAUSE I TOOK THE LOCK OFF IT." : "THE MAN ON THE CARDBOARD. I PUT A CHAIN ON THE BASEMENT DOOR IN 2019 AND TOOK IT OFF IN 2020. HE NEVER CAME IN. HE'S PROUD. IT'S THE WORST THING ABOUT HIM."));
    else L.push(say('morrow', fresh('morrow', ["HEAT'S ON. IF IT ISN'T, KICK THE RADIATOR, TOP LEFT.", "SNOW ON THE WALK IS MINE TO SHOVEL. I SHOVEL IT AT FIVE. NOBODY SEES.", "THE WOMAN IN 411 WORKS NIGHTS. IF YOU HEAR HER COME IN AT SEVEN, THAT'S THE BUILDING WORKING.", "I HAVE A NOTE FROM EVERY TENANT SINCE 2002. I KEEP THEM. I DON'T KNOW WHY.", "410'S LET. A GIRL WITH A CELLO. SHE SAID SORRY FOUR TIMES. I WROTE 'DON'T BE' AND SHE KEPT THE PAGE.", "YOU LOOK WORSE THAN DECEMBER. I'M NOT ASKING. I'M SAYING I NOTICED.", "THE BOARD IS FOR NOTICES. PEOPLE PUT UP ANYTHING. I LEAVE IT. IT'S THE ONLY PART OF THE BUILDING THAT TALKS.", "THE LOCK ON 412 STICKS. LIFT AND TURN. YOU KNOW THAT. I'M WRITING IT ANYWAY.", "TWENTY-TWO YEARS. ONE FIRE, SMALL. TWO FLOODS. FOUR TENANTS DIED IN THEIR ROOMS AND I FOUND THREE OF THEM. I'M NOT TELLING YOU THAT FOR A REASON. I'M TELLING YOU BECAUSE YOU ASKED HOW I WAS."])));
    if (m.talks === 4 && m.trust < 2) m.trust = 2;
    if (G.day >= 70 && !m.asked && m.talks >= 2) { L.push(narr('He writes for longer than usual. He does not turn the pad around right away.'), say('morrow', "I'M GOING TO ASK YOU SOMETHING AND YOU DON'T HAVE TO ANSWER."), say('morrow', "WHEN A ROOM EMPTIES, I CLEAR IT. THINGS GO IN BOXES. THE BOXES GO IN THE BASEMENT AND THEN THE CURB. I DON'T LIKE THE CURB."), say('morrow', "WHO GETS YOUR THINGS."), choice(...this.answers())); }
    Dlg.run(L);
  },
  answers() {
    const m = this.S(); const c = G.chars; const out = [];
    const pick_ = (id, label, line) => ({ t: label, do: () => { m.asked = true; m.answer = id; m.trust += 2; remember('morrow_answer_' + id); return [narr('He writes it down. One word. He underlines it, which he does not do.'), say('morrow', line), narr('He tears off the page and puts it in the drawer, on top.')]; } });
    if (c.amos.met && !c.amos.dead) out.push(pick_('Amos', 'Amos.', "THE MAN IN THE BASEMENT. GOOD. HE'LL KNOW WHAT'S WORTH KEEPING. HE'S KEPT LESS."));
    if (c.nora && c.nora.met && !c.nora.cold) out.push(pick_('Nora', 'Nora, next door.', "411. SHE'LL DO IT AT SEVEN IN THE MORNING IN SCRUBS AND NOT CRY UNTIL THE HALL. I'VE SEEN HER DO IT FOR 409."));
    if (nameKnown('jo')) out.push(pick_('Jo', 'My sister. Jo.', "FAMILY. I'LL HOLD THE ROOM TILL SHE COMES. I DON'T DO THAT. I'LL DO IT."));
    out.push(pick_('the next tenant', 'Whoever gets the room next.', "THE NEXT ONE. ...ALL RIGHT. I'LL LEAVE IT HOW YOU LEAVE IT. THAT'S NOT A THING I'VE EVER DONE EITHER."));
    out.push({ t: "I don't know yet.", do: () => [say('morrow', "OKAY."), narr('He does not tear off the page. He leaves it on the pad, and it is still there the next time you come down.')] });
    return out;
  },
  radiator() {
    const m = this.S(); if (!talkEnergy(2)) return; m.radiator = true; m.radiatorDay = G.day; remember('morrow_heat');
    Dlg.run([you("The radiator in 412. It bangs and it doesn't get warm."), narr('He writes without looking at the pad.'), say('morrow', "TOMORROW. SIX. YOU WON'T BE UP. YOU WON'T HEAR ME. IT'LL BE WARM.")]);
  },
  drawer() {
    const m = this.S(); if (!talkEnergy(2)) return; m.drawer = true; m.trust += 1; remember('morrow_drawer');
    Dlg.run([you("The drawer. The pages."), narr('He looks at you. Then he opens it and turns it so you can see: twenty-two years of torn-off pages, RENT and NO HEAT and THANK YOU and SORRY, in the same block capitals, and under them other hands, the tenants\' notes back.'), narr('Yours are near the top. RENT. - M. And under it, in your hand, on the back of an envelope, the one you slid under his door the first Monday: HERE. - 412.'), say('morrow', "I KEEP THEM. I DON'T READ THEM. I KNOW WHAT THEY SAY. IT'S THAT SOMEBODY WROTE BACK."), say('morrow', "YOU WROTE BACK. MOST DON'T.")]);
  },
  wake() {
    const m = this.S(); const d = G.day;
    if (m.radiator && d === m.radiatorDay + 1) { G.flags.own_heat = true; G.energy = clamp(G.energy + 6, 0, G.maxEnergy); G.tod = 1 - G.energy / G.maxEnergy; Dlg.run([narr('Six in the morning: a man arguing with a pipe in the wall, and the pipe giving in. The room is warm.')]); return true; }
    if (d >= 93 && !m.padlock && m.met) { m.padlock = true; remember('morrow_padlock'); Dlg.run([narr("A note under the door, block capitals, no signature needed: \"THE PADLOCK IS OFF MY DESK. IT'S IN THE DRAWER WITH THE PAGES. I'M NOT GOING TO NEED IT. - M.\"")]); return true; }
    return false;
  },
  endingLine() {
    const m = this.S(); if (!m.met) return null;
    if (m.asked) return { name: 'Morrow', line: `Twenty-two years of pages in a drawer, and one on top with a word underlined: ${m.answer}. He will clear the room the way you said. He has never done it the way anybody said.` };
    return { name: 'Morrow', line: `The super, first floor, behind the grille. ${m.radiator ? 'He fixed the heat at six in the morning so you would not have to see him do it. ' : ''}${m.drawer ? 'He showed you the drawer. ' : ''}He will clear the room; boxes, the basement, the curb. He does not like the curb.` };
  }
};

const Lobby = {
  notices() {
    const N = []; const f = G.flags, c = G.chars, d = G.day; const r = Rent.S();
    const add = (t, body, col) => N.push({ t, body, col });
    add('RENT MONDAYS', 'RENT MONDAYS. ENVELOPE UNDER THE OFFICE DOOR, OR THE WINDOW, IF YOU\'RE THE KIND WHO COMES TO THE WINDOW. - M.');
    if (r.owed > 0) add('NOTICE TO 412', `NOTICE TO 412: $${r.owed} OWED. ${r.missed >= 2 ? 'ONE MORE AND THE LOCK GOES ON.' : 'I HAVE BEEN PATIENT.'} - M.`, '#e8c0a0');
    if (d % 7 === 1 || d % 7 === 2) add('NO HEAT TUES', 'NO HEAT TUESDAY 9-12. BOILER. WEAR A COAT. - M.');
    if ((G.snow || 0) > 0.5) add('SHOVEL', 'SHOVEL YOUR WALK. THAT MEANS ME. I DO IT AT FIVE. - M.');
    if (d <= 10 && Season.lightsUp()) add('LIGHTS', 'LIGHTS COME DOWN JANUARY 5TH. LADDER IN THE BASEMENT. ASK. - R. ORTEGA, 2ND FLOOR');
    for (const k in CAL.HOLIDAYS) { const hd = +k; if (hd >= d && hd <= d + 4) add('DOCK CLOSED', `MORROW FREIGHT: CLOSED ${CAL.short(hd).toUpperCase()}, ${CAL.HOLIDAYS[k].toUpperCase()}. NO DAY LABOR. - K.`, '#d8d8e8'); }
    if (!f.dogCollar && !f.dogFollows && d >= 2) add('LOST DOG', 'LOST: BROWN DOG, NO COLLAR, ANSWERS TO NOTHING. SEEN BY THE LOT AT THE RIVER END. NOT MINE. SOMEBODY\'S.', '#f0e8c0');
    if (d < 40) add('410 TO LET', '410 TO LET. ONE ROOM. WINDOW ON THE AIR SHAFT. NO MUSICIANS. - M.');
    else if (c.signe && c.signe.arrived) add('TO 410', 'TO THE TENANT OF 410: PRACTICE HOURS 4 TO 6 ARE ACCEPTABLE. NOBODY HAS COMPLAINED. ONE PERSON ASKED FOR MORE. - M.');
    if (c.theo && c.theo.posterRead && !c.theo.reunited && !c.theo.gone) add('MISSING', 'MISSING: THEO MARSH, 16. GREY HOODIE. LAST SEEN BY THE RIVER. HIS FATHER IS LOOKING. HIS FATHER IS SORRY. - PLEASE CALL.', '#f0e0d0');
    if (c.nadia.met && !c.nadia.saved && !c.nadia.closed && d >= c.nadia.rentDay - 6) add("NADIA'S", `NADIA'S DINER: LAST DAY ${CAL.short(c.nadia.rentDay).toUpperCase()} UNLESS. COME EAT. - N.`, '#f0d0c0');
    if (c.nadia.saved) add("NADIA'S", "NADIA'S: OPEN. STAYING OPEN. THANK YOU, YOU KNOW WHO. - N. (AND SAM)", '#f0d0c0');
    if (c.signe && c.signe.band) add('FRIDAYS', 'FRIDAYS UNDER THE SHELTER, AFTER DARK: THE HARLAN STREET THREE. A GUITAR, A CELLO, A HORN. NO COVER. BRING A CRATE. - C.', '#e0d0f0');
    if (c.birdie && c.birdie.callinDay && !c.birdie.lease) add('KHRL', `KHRL 1340 AM: CALL IN ${CAL.short(c.birdie.callinDay).toUpperCase()}, AFTER NINE. SOMEBODY IS LISTENING. PROVE IT. - B.`, '#e8d8a0');
    if (c.birdie && c.birdie.dark) add('KHRL', 'KHRL 1340: OFF THE AIR. THANK YOU FOR LISTENING. I KNOW YOU WERE. - B.', '#c8c0b0');
    if (c.birdie && c.birdie.lease) add('KHRL', 'KHRL 1340, THE OVERNIGHT: STILL HERE. THE TOWER IS PAID. SOMEBODY DID THAT. - B.', '#e8d8a0');
    if (G.garden && G.garden.harvests > 0) add('VEGETABLES', "VEGETABLES BEHIND THE DINER, HECTOR'S PLOT. TAKE WHAT YOU NEED. LEAVE THE TOMATOES ON THE LEFT, THOSE ARE FOR THE DINER. - R.O.", '#d0e8c0');
    if (c.walter.dead) add('WALTER J. ASHBY', `WALTER J. ASHBY. FORTY-ONE YEARS AT THE HERALD. THE BENCH UNDER THE BUS SIGN, ELEVEN YEARS. ST. BARTHOLOMEW'S, BESIDE RUTH. THE 14 DOES NOT RUN. HE KNEW.`, '#d8d8e0');
    if (G.house && G.house.listed && !G.house.owner) add('FOR SALE', 'THE ASHBY HOUSE, THE LANE OFF THE RIVER END. TWENTY THOUSAND. SEVEN CLOCKS INCLUDED. - HARLAN REALTY');
    if (G.house && G.house.owner === 'amos') add('SOLD', 'THE ASHBY HOUSE: SOLD. TO A CARPENTER. THE CLOCKS ARE WOUND. - A.R.');
    if (d >= 89 && d <= 91) add('SUNDAY DINNER', "SUNDAY DINNER, 2ND FLOOR, THE FIRST SUNDAY OF SPRING. EVERYBODY. THAT MEANS YOU, 412. - R. ORTEGA", '#f0e0c0');
    if (d === 43 && c.nadia.met) add('412', 'HAPPY BIRTHDAY 412. COME TO THE DINER. DON\'T ASK WHY. - S.', '#f0d0d0');
    if (c.amos.dead) add('AMOS REED', 'AMOS REED. CARPENTER. HE SLEPT BY THE STOOP AND NEVER ONCE ASKED. THE CANDLE IS FOR HIM. LEAVE IT. - 412 (AND 411)', '#d8d8e0');
    if (f.house === 'mine') add('412', 'ROOM 412 TO LET. THE TENANT MOVED TO THE LANE. HE LEFT THE CRACK IN THE CEILING; IT WAS THERE WHEN HE CAME. - M.');
    if (c.morrow && c.morrow.padlock) add('TO 412', 'TO 412: THE PADLOCK IS OFF MY DESK. - M.', '#e8c0a0');
    return N;
  },
  board() {
    const N = this.notices(); remember('board_read');
    const items = N.map(n => ({ t: n.t, do: () => Dlg.run([narr(n.body)]) })); items.push({ t: 'Step back', do: () => { } });
    Menu.open('The board', items, { wide: true, sub: `Cork, thumbtacks, a pen on a string. ${N.length} notice${N.length === 1 ? '' : 's'}.` });
  },
  door(d) {
    const room = G.chars.amos.room;
    if (d.office) { if (Morrow.here()) Morrow.menu(); else Dlg.run([narr('The office is dark. A card in the grille, block capitals: BACK AT 7. IF IT\'S THE HEAT, KICK IT, TOP LEFT.')]); return; }
    if (d.lobbyStairs) {
      Audio.sel(); const up = () => UI.fadeOut(() => { goSceneNow('hall', 'stairs'); UI.fadeIn(); useStairs('up'); }, 0.08);
      if (room) Menu.open('Stairs', [{ t: 'Up to your floor (4)', do: up }, { t: 'Down to the basement (Amos)', do: () => UI.fadeOut(() => { goSceneNow('basement', 'stairs'); UI.fadeIn(); useEnergy(1); Dlg.run([narr('One flight down. The stairwell smells like the boiler and, faintly, sawdust.')]); }, 0.08) }, { t: 'Never mind', do: () => { } }]);
      else up();
      return;
    }
    if (d.lobbyElev) {
      if (G.elevatorBroken) { UI.toast('Out of order. Again.', '#e86a6a'); Audio.bad(); return; }
      Audio.sel(); const up = () => Elevator.start('up', () => { goSceneNow('hall', 'elevator'); }, 1, 4);
      if (room) Menu.open('Elevator', [{ t: 'Your floor (4)', do: up }, { t: 'Basement (B)', do: () => Elevator.start('down', () => { goSceneNow('basement', 'elevator'); }, 1, 0) }, { t: 'Never mind', do: () => { } }]);
      else up();
      return;
    }
    goScene(d.to, d.at);
  },
  arrive() {
    const m = Morrow.S(); if (m.seenLobby) return; m.seenLobby = true;
    Dlg.run([narr('The lobby of Harlan Arms: a checkerboard floor with the checks worn off in a path, brass mailboxes, a corkboard, a radiator that ticks, and a window with a grille in it and a light behind the grille.')]);
  }
};
{
  // the building door now opens on the lobby; the stairs and the elevator come down to it
  enterBuilding = function () { Audio.sel(); goScene('lobby', 'street'); };
  const hdL = hallDoor; hallDoor = function (d) {
    const here = G.scene; const room = G.chars.amos.room;
    if (d && d.elevator && (here === 'hall' || here === 'basement')) {
      if (G.elevatorBroken) { UI.toast('Out of order. Again.', '#e86a6a'); Audio.bad(); return; }
      Audio.sel(); const toLobby = () => Elevator.start(here === 'hall' ? 'down' : 'up', () => { goSceneNow('lobby', 'elevator'); }, here === 'hall' ? 4 : 0, 1);
      if (here === 'hall' && room) Menu.open('Elevator', [{ t: 'Lobby (1)', do: toLobby }, { t: 'Basement (B)', do: () => Elevator.start('down', () => { goSceneNow('basement', 'elevator'); }, 4, 0) }, { t: 'Never mind', do: () => { } }]);
      else if (here === 'basement') Menu.open('Elevator', [{ t: 'Lobby (1)', do: toLobby }, { t: 'Your floor (4)', do: () => Elevator.start('up', () => { goSceneNow('hall', 'elevator'); }, 0, 4) }, { t: 'Never mind', do: () => { } }]);
      else toLobby();
      return;
    }
    if (d && d.stairs && (here === 'hall' || here === 'basement')) {
      Audio.sel();
      const toLobby = () => UI.fadeOut(() => { goSceneNow('lobby', 'stairs'); UI.fadeIn(); if (here === 'hall') useStairs('down'); else Dlg.run([narr('One flight up.')]); }, 0.08);
      if (here === 'hall' && room) Menu.open('Stairs', [{ t: 'Down to the lobby', do: toLobby }, { t: 'Down to the basement (Amos)', do: () => UI.fadeOut(() => { goSceneNow('basement', 'stairs'); UI.fadeIn(); useEnergy(2); Dlg.run([narr('Five flights down. The last one is unlit. You count the steps by feel.')]); }, 0.08) }, { t: 'Never mind', do: () => { } }]);
      else if (here === 'basement') Menu.open('Stairs', [{ t: 'Up to the lobby', do: toLobby }, { t: 'Up to your floor (4)', do: () => UI.fadeOut(() => { goSceneNow('hall', 'stairs'); UI.fadeIn(); useStairs('up'); }, 0.08) }, { t: 'Never mind', do: () => { } }]);
      else toLobby();
      return;
    }
    return hdL(d);
  };
  const oesL = onEnterScene; onEnterScene = function (sc) { oesL(sc); if (sc === 'lobby') Lobby.arrive(); };
  const weL = wakeEvents; wakeEvents = function () { if (Morrow.wake()) return; weL.apply(this, arguments); };
  const belL = buildEndingList; buildEndingList = function () { const out = belL(); const ml = Morrow.endingLine(); if (ml) out.push(ml); return out; };
  NAME_RULES.push({ id: 'morrow', re: /\bMorrow('s)?\b(?! Freight| FREIGHT)/g, sub: 'the super' });
  const nkL = nameKnown; nameKnown = function (id) { if (id === 'morrow') return !!(G.chars.morrow && G.chars.morrow.met) || (G.rent && G.rent.notes > 0) || G.day > 8; return nkL(id); };
  FRESH.morrow = [];
  FRESH.nora = FRESH.nora || []; FRESH.nora.push(L_("Morrow fixed your heat? He's never fixed mine. He fixed mine the day after yours. He thinks I don't know it was because of you.", () => !!(G.chars.morrow && G.chars.morrow.radiator)));
  FRESH.amos = FRESH.amos || []; FRESH.amos.push(L_("Morrow took the lock off the basement door in 2020. I know. I watched him do it from the cardboard. He didn't look at me. That's how you know a man means it.", () => !!(G.chars.morrow && G.chars.morrow.talks >= 5)));
}
