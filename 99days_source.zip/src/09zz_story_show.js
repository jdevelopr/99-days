// ============================================================
// Shown, not told: the things people said they would do, happening on their own time.
// ============================================================
{
  // mornings: the bed arrives, the note comes back, the marigolds go in
  const weZ = wakeEvents; wakeEvents = function () {
    const f = G.flags; const d = G.day;
    if (f.bedDay && d > f.bedDay && !f.betterBed) { f.betterBed = true; f.own_bed = true; delete interiorCache.apartment; }
    { const r = Rent.S(); if (r.noteDay && d > r.noteDay && !r.noteSeen) { r.noteSeen = true; r.noteDay = 0; Dlg.run([narr('Under the door: PAID. THANK YOU. - M. The thank you is new.')]); return; } }
    { const s = G.garden; if (s && s.meiJoinDay) { if (d >= s.meiJoinDay + 1) s.flowers = true; if (d >= s.meiJoinDay + 2) s.drawn = true; } }
    weZ.apply(this, arguments);
  };
  // Theo, the morning after his father came to the corner
  const ttZ = Theo.talk; Theo.talk = function () {
    const b = Beats.S(); if (b.theoWarnedPending) { b.theoWarnedPending = false; if (!talkEnergy()) return; Dlg.run([you("Your dad came to the corner. He asked if you were alive. I said yes. That's all I said."), narr('He goes white and then he does not run, which is new.'), say('theo', "He stood under it? Under the poster?"), say('theo', "...Okay. Okay. Just Cal. Still just Cal. But okay.")]); return; }
    return ttZ.apply(this, arguments);
  };
  // the railing at dawn, after you told his father where
  const buZ = Beats.update; Beats.update = function () {
    buZ.apply(this, arguments); const b = this.S();
    if (b.theoRailPending && G.scene === 'street' && G.state === 'play' && G.tod < 0.22 && Math.abs(G.px - (STREET.spots.river + 40)) < 60 && !Dlg.active) { b.theoRailPending = false; Dlg.run([narr('A marker on the rail, and a half-drawn bridge, and nobody.')]); }
  };
  // Walter, the afternoon the radio works again
  const beZ = buildEntities; buildEntities = function () { beZ(); if (G.flags.radioDay === G.day && G.entities) { const w = G.entities.find(e => e.id === 'walter'); if (w && !w.bubble) w.bubble = 'note'; } };
  // the heater in the alley, at night
  const dpZ = drawPuddles; drawPuddles = function (g, ents, camX, pal, t) {
    dpZ(g, ents, camX, pal, t);
    const a = G.chars.amos; if (G.scene !== 'street' || !a.heater || a.room || a.dead || pal.night < 0.05) return;
    const sx = 236 - camX; if (sx < -60 || sx > W + 60) return;
    g.save(); g.globalCompositeOperation = 'lighter'; const rg = g.createRadialGradient(sx, FEET_Y - 4, 2, sx, FEET_Y - 4, 34 + Math.sin(t * 0.1) * 2); rg.addColorStop(0, `rgba(255,120,40,${0.22 * pal.night})`); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = rg; g.fillRect(sx - 40, FEET_Y - 44, 80, 50); g.restore();
  };
  // Mrs. Ortega, about the pharmacy call
  const gmZ = Minor.granny; Minor.granny = function () {
    if (G.flags.wrongOrtega && !G.flags.tamale) { G.flags.tamale = true; addHunger(20); Dlg.run([say('granny', "You! The pharmacy called YOU. They have had the wrong floor since Hector; I have told them nine times."), narr('She puts a tamale in your hand, warm, from somewhere in her coat.'), say('granny', "For taking the call. Eat it before it gets ideas.")]); return; }
    gmZ.call(this);
  };
  FRESH.nora = FRESH.nora || []; FRESH.nora.push(L_("Your friend. Amos. He read a letter on the fourth-floor landing yesterday, standing up, twice, and then sat on the stairs for an hour. I stepped around him. Everybody did. Nobody said anything, which was right.", () => !!(G.beats && G.beats.amosLetter)));
}
