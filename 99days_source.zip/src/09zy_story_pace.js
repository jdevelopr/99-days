// ============================================================
// Pace: one story conversation per person per day. The rest of the day they have other things to say.
// And the things people said on the phone, happening where they said they would.
// ============================================================
const PACE_FILLER = {
  amos: ["We talked. Go do something. I'll be here; I'm always here.", "Later. Rain's picking up; I'm going under the awning.", "You already said good morning. I'm holding you to it."],
  mei: ["Bread's five. We covered the rest.", "I'm working. Come back tomorrow, I'll have drawn something.", "Mom's watching. Buy something or go."],
  nadia: ["Sit or don't, but I've got a floor to do.", "We talked. Eat something.", "Later. The lunch crowd, which is two people, is coming."],
  nora: ["I've got four hours of sleep to get. Tomorrow.", "We talked. Go take the pills.", "Later. I'm dead on my feet."],
  walter: ["We talked. Sit if you want; you don't have to say anything.", "Later. The bus isn't coming and neither is anything I haven't said.", "Ruth would say I've talked enough for one day. Ruth was right about most things."],
  sol: ["We talked. Buying or selling.", "The book's closed for the day. Tomorrow.", "You've had your conversation. I ration them."],
  emmett: ["Fish don't bite twice. Neither do I. Tomorrow.", "We talked. Sit and watch the water; it's what it's for.", "..."],
  signe: ["...", "Tomorrow.", "I have said my words for today."],
  birdie: ["The light's about to go red. Sit on the couch.", "We talked. I've got a river to talk to.", "Tomorrow. Nine. Same as always."],
  morrow: ["WE TALKED.", "TOMORROW.", "THE PAD'S FULL FOR TODAY."],
};
const Pace = {
  // wrap a character's story talk so it runs once a day; the rest of the day is small talk
  wrap(obj, key, id, getState) {
    const f0 = obj[key];
    obj[key] = function () {
      const c = getState(); if (!c) return f0.apply(this, arguments);
      const wasMet = !!c.met;
      if (wasMet && c.storyDay === G.day && !c.cold) {
        if (!talkEnergy(1)) return;
        Dlg.run([say(id, fresh(id, PACE_FILLER[id] || ['...']))]); return;
      }
      const r = f0.apply(this, arguments);
      if (c.met) c.storyDay = G.day;
      return r;
    };
  }
};
{
  Pace.wrap(Amos, 'talk', 'amos', () => G.chars.amos);
  Pace.wrap(Mei, 'talk', 'mei', () => G.chars.mei);
  Pace.wrap(Nadia, 'talk', 'nadia', () => G.chars.nadia);
  Pace.wrap(Nora, 'talk', 'nora', () => G.chars.nora);
  Pace.wrap(Walter, 'talk', 'walter', () => G.chars.walter);
  Pace.wrap(Pawn, 'talk', 'sol', () => G.chars.sol);
  Pace.wrap(Emmett, 'talk', 'emmett', () => G.chars.emmett);
  Pace.wrap(Cello, 'talk', 'signe', () => G.chars.signe);
  Pace.wrap(Radio, 'talk', 'birdie', () => G.chars.birdie);
  Pace.wrap(Morrow, 'talk', 'morrow', () => G.chars.morrow);

  // ---- the phone calls, kept ----
  // Nadia: "Come by. I'll feed you and he'll feed you fractions."
  const oesP = onEnterScene; onEnterScene = function (sc) {
    oesP(sc); const P = G.phone; if (!P) return;
    if (sc === 'diner' && P.friends.nadia && !G.flags.fractionsDone && G.chars.nadia.sam && !G.chars.nadia.closed) { G.flags.fractionsDone = true; G.hunger = Math.min(100, G.hunger + 35); G.ateToday = true; trust('nadia', 1); remember('fractions'); Dlg.run([narr('Sam has the booth and the worksheet and the look of a boy who has been promised somebody.'), say('kid', "Three-eighths plus one-quarter. Go."), you("Five-eighths."), say('kid', "...He said you knew fractions. He didn't say you were fast."), narr('Nadia puts the 412 in front of you without asking. You do the whole page. He checks every one against the back of the book and does not find one wrong, and is disappointed, and is not.')]); }
  };
  // Sol: "Come in sometime; I'll show you the page."
  const pmP = Pawn.menu; Pawn.menu = function () { pmP.call(this); const P = G.phone; const s = G.chars.sol; if (Menu.active && P && P.friends.sol && !s.pageShown) Menu.items.splice(1, 0, { t: 'Ask to see the page', do: () => { s.pageShown = true; s.trust += 1; remember('sol_page'); Dlg.run([narr('He turns the ledger around without being asked twice. A page near the back. Names, dates, objects, in his hand, going down the column.'), narr('Your name is on it. Not with a thing beside it; with a phone number, and a date in January, and in the margin, smaller: PICKED UP.'), say('sol', "Forty-one years of Januaries. One line says picked up. It's a good page. I'll leave it in.")]); } }); };
  // Cal: "I'm playing it Friday under the shelter."
  const bmP = Minor.busker; Minor.busker = function () { bmP.call(this); const P = G.phone; if (Menu.active && P && P.friends.busker && G.day % 7 === 5 && !G.flags.walterSongHeard) Menu.items.splice(1, 0, { t: "Hear the song for Walter", r: '-3 energy', do: () => { if (!talkEnergy(3)) return; G.flags.walterSongHeard = true; remember('walter_song'); const sp = SONGS.find(x => x.id === 'the14'); if (sp) Song.play(sp); } }); };
  // Mei: "I'm going to open it when you're at the counter."
  const mmP = Mei.menu; Mei.menu = function () { mmP.call(this); const P = G.phone; const m = G.chars.mei; if (Menu.active && P && P.friends.mei && !m.accepted && !m.cold && m.stage >= 3) Menu.items.splice(1, 0, { t: 'The envelope', do: () => { m.storyDay = 0; Mei.talk(); } }); };
  // Jo: "I'll call Thursday."
  const paP = Phone.answer; Phone.answer = function () { const P = this.P(); const was = P.callToday; paP.call(this); if (was === 'jo_birthday') { const j = Jo.J(); let d = G.day + 1; while (d % 7 !== 4) d++; j.nextDay = d; } };
  // Mei: "Saturday." The bus pass, and the school
  const gmP = Gifts.mei; Gifts.mei = function (items) { gmP.call(this, items); const it = items.find(i => /bus pass/.test(i.t)); if (it) { const d0 = it.do; it.do = () => { d0(); G.chars.mei.busPassDay = G.day; }; } };
  const meiSat = () => { const m = G.chars.mei; if (!m.busPassDay) return null; let d = m.busPassDay + 1; while (d % 7 !== 6) d++; return d; };
  const mmS = Mei.menu; Mei.menu = function () { const sat = meiSat(); if (sat && G.day === sat && !G.chars.mei.cold) { Dlg.run([narr('Mrs. Lin is at the register. Mei is not.'), say('mrsLin', "The school. Saturday. She took a bus; she said you gave her the bus. Bread is five.")]); return; } mmS.call(this); };
  FRESH.mei = FRESH.mei || []; FRESH.mei.push(L_("I went. Saturday. The school. There's a room with forty easels and north light, and nobody in it was drawing a lamp. I drew the lamp anyway. From memory.", () => { const s = meiSat(); return !!(s && G.day > s); }), L_("The bus back from the school had a man drawing on his hand. I drew him drawing on his hand. It's a whole thing now.", () => { const s = meiSat(); return !!(s && G.day > s + 2); }));
  // Nadia: "Catch of the day."
  FRESH.nadia = FRESH.nadia || []; FRESH.nadia.push(L_("Catch of the day. Perch. Two people asked where from. I said a fisherman. I didn't say which one.", () => G.flags.fishSoldDay && G.day === G.flags.fishSoldDay + 1), L_("Sold the last of the perch. Somebody asked if it'd be back. I said ask the fisherman.", () => G.flags.fishSoldDay && G.day === G.flags.fishSoldDay + 2));
  // Amos: "Something square."
  const amP = Amos.menu; Amos.menu = function () {
    const a = G.chars.amos; if (a.tools && !a.madeBox && G.day >= (G.flags.amosToolsDay || 0) + 4 && !a.dead && G.scene !== 'dock') { a.madeBox = true; G.flags.amosBox = true; trust('amos', 1); remember('amos_box'); Dlg.run([narr('He has something behind his back, which on Amos is a whole announcement.'), narr('A box. Square, dovetailed, the lid fitted so close it sighs when you lift it. Nothing in it. Sanded until the grain shows through like a map.'), say('amos', "Something square. I said. It took four days because the plane needed sharpening and I'd forgotten how, and then I remembered."), say('amos', "Put something in it. Not for me. For whoever opens it after.")]); return; }
    amP.call(this);
  };
  const gtP = Gifts.amos; Gifts.amos = function (items) { gtP.call(this, items); const it = items.find(i => /his tools/.test(i.t)); if (it) { const d0 = it.do; it.do = () => { d0(); G.flags.amosToolsDay = G.day; }; } };
  const adP = INTERIORS.apartment.dynamic; INTERIORS.apartment.dynamic = function (g, t) { if (adP) adP.call(this, g, t); if (G.flags.amosBox) { px(g, 198, COUNTER_TOP - 8, 12, 8, '#8a6a3a'); px(g, 198, COUNTER_TOP - 8, 12, 1, '#a8885a'); px(g, 199, COUNTER_TOP - 5, 10, 1, '#5a4020'); } };
}
