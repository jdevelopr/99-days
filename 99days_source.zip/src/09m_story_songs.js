// ============================================================
// Cal's songs. Four of them, about thirty seconds each, in rotation. "Listen a while" plays the next one.
// The specs live in 09l_songs_data.js and the instruments in 09l_synth.js; this is the player: state, lyrics, the outro.
// ============================================================
S('note', ['..YY', '..YY', '..Y.', '..Y.', 'YYY.', 'YYY.'], { Y: '#f8e88a' });
// unlock rules and the "when" of alternate lyrics, by name, so the songs can stay pure data
const SONG_RULES = {
  always: () => true, never: () => false,
  theoReunited: () => !!(G.chars.theo && G.chars.theo.reunited),
  bandNight: () => !!(Cello.S().band && Cello.bandTonight()),
  walterDead: () => !!G.chars.walter.dead,
};
function songRule(name) { if (!name || name === 'always') return () => true; if (SONG_RULES[name]) return SONG_RULES[name]; let m; if ((m = /^day\s*>=\s*(\d+)$/.exec(name))) return () => G.day >= +m[1]; if ((m = /^flag:(\w+)$/.exec(name))) return () => !!G.flags[m[1]]; return () => false; }
const SONGS = SONG_DATA.map(d => { const s = Object.assign({}, d); s.unlockFn = songRule(d.unlock); if (s.alt) s.whenFn = songRule(s.alt.when); return s; });
const SOL_SONG = SONGS.find(s => s.id === 'sol1994');
const Song = {
  active: false, spec: null, nodes: [], startAt: 0, dur: 0, lyricIdx: -1, shown: '',
  next() { const f = G.flags; const avail = SONGS.filter(s => !s.solo && s.unlockFn()); const i = (f.songIdx || 0) % avail.length; f.songIdx = i + 1; const s = avail[i]; if (s.id === 'sixth') { Beats.S().theoSongHeard = true; remember('song_sixth'); } return s; },
  play(spec) {
    const A = Audio; if (!A._unlocked) A.unlock();
    this.spec = spec; this.active = true; this.lyricIdx = -1; this.shown = ''; this.nodes = []; this.startedFrame = G.t; G.state = 'song'; G.walking = false; G.facing = STREET.spots.busker > G.px ? 1 : -1;
    const beat = SYNTH.beat(spec); this.dur = SYNTH.duration(spec); this.beatsTotal = SYNTH.totalBeats(spec); this.beatLen = beat;
    if (!A._unlocked || A.muted) { this.startAt = 0; return; }
    const c = A.ctx; const t0 = c.currentTime + 0.15; this.startAt = t0; this.ctxStart = t0;
    const r = SYNTH.schedule(c, A.master, spec, t0, { mute: spec.who === 'sol' && G.chars.sol && G.chars.sol.mute }); this.nodes = r.nodes;
  },
  update() {
    if (!this.active) return;
    const elapsed = (G.t - this.startedFrame) / 60;
    const beatNow = elapsed / this.beatLen;
    const ly = this.lyrics(); let idx = -1; for (let i = 0; i < ly.length; i++) if (beatNow >= ly[i][0] - 0.2) idx = i; this.lyricIdx = idx;
    if (Input.hit('back') || Input.hit('menu')) { this.stop(true); return; }
    if (elapsed >= this.dur) this.stop(false);
  },
  useAlt() { const s = this.spec; return !!(s.alt && s.whenFn && !s.whenFn()); },
  lyrics() { const s = this.spec; return this.useAlt() ? s.alt.lyrics : s.lyrics; },
  stop(early) {
    this.active = false; G.state = 'play';
    if (early && Audio.ctx) SYNTH.hush(Audio.ctx, this.nodes);
    this.nodes = [];
    const s = this.spec; const outro = this.useAlt() ? s.alt.outro : s.outro;
    if (!s.solo) G.flags.songsHeard = (G.flags.songsHeard || 0) + (early ? 0 : 1); if (!early) remember('song_' + s.id);
    if (s.after) { s.after(early); return; }
    Dlg.run([narr(early ? (s.early || 'You walk on before the end. He does not stop; the song was not for you, particularly. It was for the corner.') : outro)]);
  },
  draw(g, t) {
    buildEntities(); const b = G.entities.find(e => e.id === 'busker'); if (b) b.bubble = 'note';
    renderScene(g, t); UI.drawHud(g, t);
    const s = this.spec; const title = this.useAlt() ? s.alt.title : s.title;
    UI.panel(g, W / 2 - 110, 30, 220, 14, 0.75); drawText(g, `"${title}"`, W / 2, 33, '#e8c84a', { align: 'center' });
    const ly = this.lyrics();
    if (this.lyricIdx >= 0) { const text = ly[this.lyricIdx][1]; const lines = wrapText(text, 300); const w = Math.max(...lines.map(l => textWidth(l))) + 16; UI.panel(g, Math.round(W / 2 - w / 2), 48, w, 8 + lines.length * 10, 0.7); lines.forEach((ln, i) => drawText(g, ln, W / 2, 52 + i * 10, '#f0ead8', { align: 'center' })); }
    // progress
    const p = clamp((G.t - this.startedFrame) / 60 / this.dur, 0, 1); px(g, W / 2 - 60, 26, 120, 1, 'rgba(255,255,255,0.15)'); px(g, W / 2 - 60, 26, Math.round(120 * p), 1, '#e8c84a');
    UI.drawHint(g, `${UI.keyName('back')} ${s.hint || 'walk on'}`);
  }
};
