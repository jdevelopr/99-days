// ============================================================
// Nobody is named before you have met them. Dialogue and day cards swap unmet names for who they are to you so far.
// ============================================================
function nameKnown(id) {
  const c = G && G.chars; if (!c) return true; const f = G.flags || {};
  switch (id) {
    case 'amos': return !!c.amos.met;
    case 'walter': return !!c.walter.met;
    case 'nadia': return !!c.nadia.met;
    case 'nora': return !!(c.nora && c.nora.met);
    case 'mei': return !!c.mei.met;
    case 'emmett': return !!(c.emmett && c.emmett.met);
    case 'sol': return !!(c.sol && c.sol.met);
    case 'theo': return !!(c.theo && (c.theo.visits > 0 || c.theo.reunited || c.theo.posterRead));
    case 'cal': return !!(c.theo && c.theo.calNamed) || (f.buskerTips || 0) >= 3 || !!(G.beats && G.beats.trumpetPlayed) || !!f.calKnown;
    case 'ortega': return (f.grannyHelped || 0) > 0 || (f.ortegaBus || 0) > 0 || !!f.grannyPhone;
    case 'sam': return !!c.nadia.sam;
    case 'ruth': return !!c.walter.met;
    case 'hector': return (f.grannyHelped || 0) > 0 || (f.ortegaBus || 0) > 0 || !!(G.garden && G.garden.unlocked);
    case 'jo': return !!(G.phone && G.phone.jo && (G.phone.jo.stage >= 1 || G.phone.jo.calls > 0));
    case 'micah': return !!(G.phone && G.phone.jo && G.phone.jo.stage >= 2);
    case 'lena': return !!(c.emmett && c.emmett.stage >= 2);
    case 'kowalski': return !!(G.beats && G.beats.foremanName) || !!f.manager;
    default: return true;
  }
}
const NAME_RULES = [
  { id: 'amos', re: /\b(?:Amos|Reed)('s)?\b/g, sub: 'the man by the stoop' },
  { id: 'walter', re: /\bWalter(?: J\.)?(?: Ashby)?('s)?\b/g, sub: 'the old man on the bench', poss: "the old man's" },
  { id: 'nadia', re: /\bNadia('s)?\b/g, sub: 'the woman at the diner', poss: 'the diner' },
  { id: 'nora', re: /\bNora('s)?\b/g, sub: 'your neighbor' },
  { id: 'mei', re: /\bMei('s)?\b/g, sub: 'the girl at the market' },
  { id: 'emmett', re: /\bEmmett('s)?\b/g, sub: 'the man on the pier' },
  { id: 'sol', re: /\bSol('s)?\b(?! Pawn)/g, sub: 'the pawnbroker', poss: "the pawn shop's" },
  { id: 'theo', re: /\bTheo('s)?\b/g, sub: 'the kid' },
  { id: 'cal', re: /\bCal('s)?\b/g, sub: 'the busker' },
  { id: 'ortega', re: /\b(?:Mrs\. )?Ortega('s)?\b/g, sub: 'the old woman with the oranges', poss: "the old woman's" },
  { id: 'sam', re: /\bSam('s)?\b/g, sub: 'her boy' },
  { id: 'ruth', re: /\bRuth('s)?\b/g, sub: 'his wife' },
  { id: 'hector', re: /\bHector('s)?\b/g, sub: 'her husband' },
  { id: 'jo', re: /\b(?:Jo|Joanne)('s)?\b/g, sub: 'your sister' },
  { id: 'micah', re: /\bMicah('s)?\b/g, sub: 'the kid on the line' },
  { id: 'lena', re: /\bLena('s)?\b/g, sub: 'his daughter' },
  { id: 'kowalski', re: /\bKowalski('s)?\b/g, sub: 'the foreman' },
];
function gateNames(text) {
  if (!text || !G || !G.chars) return text;
  let out = text;
  for (const r of NAME_RULES) {
    if (nameKnown(r.id)) continue;
    out = out.replace(r.re, (m, poss, off, str) => {
      let rep = poss ? (r.poss || r.sub + "'s") : r.sub;
      const before = str.slice(0, off).replace(/["'(\[]+$/, '').trimEnd();
      if (before === '' || /[.!?:]$/.test(before)) rep = rep.charAt(0).toUpperCase() + rep.slice(1);
      return rep;
    });
  }
  return out;
}
// what the dialogue box calls a speaker you have not met
function displayName(id, name) {
  const map = { amos: 'Man', walter: 'Old man', nadia: 'Woman', nora: 'Neighbor', mei: 'Clerk', emmett: 'Man on the pier', sol: 'Pawnbroker', theo: 'Kid', busker: 'Busker', granny: 'Old woman', kid: 'Boy', jo: 'Voice', micah: 'Boy', lena: 'Woman' };
  const key = id === 'busker' ? 'cal' : id === 'granny' ? 'ortega' : id === 'kid' ? 'sam' : id;
  if (map[id] !== undefined && !nameKnown(key)) return map[id];
  return name;
}
{
  const dl = dayLine; dayLine = function () { return gateNames(dl()); };
  const bl = Minor.busker; Minor.busker = function () { bl.call(this); if (Menu.active && Menu.title === 'Cal') G.flags.calKnown = true; };
}
