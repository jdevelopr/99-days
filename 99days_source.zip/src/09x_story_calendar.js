// ============================================================
// The calendar: day 1 is Monday, December 27. Winter into spring. Snow some days, rain some days, sun some days.
// ============================================================
const CAL = {
  MONTHS: ['December', 'January', 'February', 'March', 'April'], LEN: [31, 31, 28, 31, 30], START: 27,
  SHORT: ['DEC', 'JAN', 'FEB', 'MAR', 'APR'], WD: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], WDS: ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'],
  dateOf(day) { let m = 0, d = this.START + day - 1; while (d > this.LEN[m]) { d -= this.LEN[m]; m++; } return { m, d, wd: day % 7 }; },
  dayOf(m, d) { let day = 1 - this.START + 1; for (let i = 0; i < m; i++) day += this.LEN[i]; return day + d - 1; },
  long(day) { const x = this.dateOf(day); return `${this.WD[x.wd]}, ${this.MONTHS[x.m]} ${x.d}`; },
  short(day) { const x = this.dateOf(day); return `${this.WDS[x.wd]} ${this.SHORT[x.m]} ${x.d}`; },
  md(day) { const x = this.dateOf(day); return `${this.MONTHS[x.m]} ${x.d}`; },
  // the days that are somebody's
  HOLIDAYS: { 6: "New Year's Day", 22: 'Martin Luther King Day', 57: "Presidents' Day" },
  EVENTS: { 5: "New Year's Eve", 6: "New Year's Day", 10: 'Twelfth Night', 22: 'Martin Luther King Day', 38: 'Groundhog Day', 43: 'Your birthday', 50: "Valentine's Day", 57: "Presidents' Day", 81: "St. Patrick's Day", 84: 'First day of spring', 91: 'The first Sunday of spring', 96: "April Fools' Day" },
  holiday(day) { return this.HOLIDAYS[day] || null; },
  event(day) { return this.EVENTS[day] || null; },
  weekend(day) { return day % 7 === 0 || day % 7 === 6; },
  dockClosed(day) { return this.weekend(day) || !!this.HOLIDAYS[day]; },
  closedWhy(day) { return this.HOLIDAYS[day] ? this.HOLIDAYS[day] : day % 7 === 0 ? 'Sunday' : 'Saturday'; },
};
// the weekday name the rest of the game already uses
weekdayName = function (day) { return CAL.WDS[day % 7]; };

// ---------- weather ----------
const Weather = {
  // kind for a day: snow | sleet | rain | grey | clear
  kind(day) {
    const R = seeded(G.weatherSeed + day * 131); const r = R();
    const forced = { 1: 'snow', 5: 'clear', 6: 'grey', 10: 'clear', 22: 'snow', 43: 'rain', 50: 'snow', 76: 'snow', 84: 'clear', 91: 'clear', 96: 'rain', 99: 'clear' };
    if (forced[day]) return forced[day];
    const kindness = Math.min(0.12, (G.memories ? G.memories.length : 0) * 0.004);
    let P;
    if (day < 36) P = { snow: 0.38, sleet: 0.10, rain: 0.14, grey: 0.22, clear: 0.16 };
    else if (day < 64) P = { snow: 0.28, sleet: 0.10, rain: 0.24, grey: 0.16, clear: 0.22 };
    else if (day < 84) P = { snow: 0.10, sleet: 0.06, rain: 0.40, grey: 0.16, clear: 0.28 };
    else P = { snow: 0, sleet: 0, rain: 0.38, grey: 0.14, clear: 0.48 };
    P.clear += kindness; P.snow = Math.max(0, P.snow - kindness / 2); P.rain = Math.max(0, P.rain - kindness / 2);
    let acc = 0; for (const k of ['snow', 'sleet', 'rain', 'grey', 'clear']) { acc += P[k]; if (r < acc) return k; }
    return 'clear';
  },
  label(kind) { return { snow: 'Snow', sleet: 'Sleet', rain: 'Rain', grey: 'Overcast', clear: 'Clear' }[kind] || ''; },
  // called when the day changes (and at new game)
  roll() {
    const R = seeded(G.weatherSeed + G.day * 131 + 7); R();
    const k = this.kind(G.day); G.weather = k;
    G.rain = k === 'rain' ? 0.45 + R() * 0.55 : k === 'sleet' ? 0.2 + R() * 0.25 : 0;
    G.snowing = k === 'snow' ? 0.5 + R() * 0.5 : k === 'sleet' ? 0.3 : 0;
    if (G.day === 1) { G.rain = 0; G.snowing = 0.8; }
    G.wind = R() * 0.8;
    G.elevatorBroken = G.day >= 3 && R() < 0.22;
    // the ground: what is on it
    if (G.snow === undefined) G.snow = 0;
    if (G.day === 1) G.snow = 0.55;
    else if (k === 'snow') G.snow = Math.min(1, G.snow + 0.3);
    else if (k === 'sleet') G.snow = Math.min(1, G.snow + 0.05);
    else if (k === 'rain') G.snow = Math.max(0, G.snow - (G.day < 64 ? 0.18 : 0.3));
    else if (k === 'grey') G.snow = Math.max(0, G.snow - (G.day < 64 ? 0.04 : 0.1));
    else G.snow = Math.max(0, G.snow - (G.day < 64 ? 0.08 : 0.2));
    if (G.day >= 84) G.snow = 0;
    G.cold = G.day < 70 ? k !== 'clear' || G.day < 40 : k === 'snow' || k === 'sleet';
    // snowmen: the kids build them on snow days, and the sun takes them
    G.snowmen = G.snowmen || [];
    if (k === 'snow' && G.snow >= 0.3 && G.day >= 2) { for (const x of [1985, 610]) if (!G.snowmen.some(s => s.x === x)) G.snowmen.push({ x, built: G.day, hat: R() < 0.5 }); }
    G.snowmen = G.snowmen.filter(s => G.snow > 0.12 && G.day - s.built < 12);
    G.prints = [];
    Audio.setWeather(k, G.rain, G.snowing);
  }
};
rollWeather = function () { Weather.roll(); };

// ---------- the days that are somebody's: mornings, and one night ----------
const Season = {
  S() { if (!G.season) G.season = { nye: false, lights: false, lightsSeen: false, cake: false, card: null, spring: false, dinner: false }; return G.season; },
  wake() {
    const s = this.S(); const d = G.day; const c = G.chars;
    if (d === 5) { Dlg.run([narr("December 31st. The last day of the year, which the street treats like the last day of anything: Lin's has a sign up that says OPEN LATE, and Nadia has a sign up that says OPEN LATER."), narr('At midnight there are fireworks over the river, Mrs. Ortega says, if the rain lets them. You could be at the railing for it.')]); return true; }
    if (d === 6) { Dlg.run([narr(`January 1st. ${s.nye ? 'The fireworks are still in your eyes a little.' : 'You heard the fireworks from the bed and did not get up, which is a thing you have done every year and will not do again.'} The dock is closed; the street is very quiet, and the few people on it are walking carefully.`), narr(c.walter.met ? 'Walter, on the bench, with a paper cup that is not coffee: "Happy new year. Ruth used to say it to the bus. I say it to the bus."' : 'Somebody has left a paper hat on the bench under the bus sign.')]); return true; }
    if (d === 10 && !s.lights) { Dlg.run([narr('January 5th. Twelfth Night; the lights come down today, Mrs. Ortega says, or the year goes badly. She is on the sidewalk with a stepladder and the boy from the diner, and neither of them can reach.')]); return true; }
    if (d === 11 && !s.lights) { s.lights = true; Dlg.run([narr('The lights are gone from the street. Mrs. Ortega and the boy did it without you, in the dark, and there is a box on the stoop with the string spilling out of it like something that lost.')]); return true; }
    if (d === 22) { Dlg.run([narr("Martin Luther King Day. The dock is closed and the clinic is closed and Birdie, last night, played the whole speech, and then said nothing for the length of it again, which she has never done."), narr('A day with nothing in it. The rarest kind.')]); return true; }
    if (d === 38) { Dlg.run([narr('February 2nd. Groundhog Day. Cal, on the corner, has been saying "six more weeks" to everybody since seven. Nobody has asked him six more weeks of what.')]); return true; }
    if (d === 43) { Dlg.run([narr("February 7th. You did not tell anybody. You did not write it on the calendar. The pills do not know and the rain does not know."), narr(c.nadia.met ? 'There is a note under the door in a child\'s handwriting: "MOM SAYS COME TO THE DINER TODAY. DON\'T ASK WHY. - SAM." Nadia knows. Nadia knows everything; it is on the form the first time you ate there and she read the form.' : "Somebody's birthday. Yours. It goes on being yours for about an hour and then it is a Thursday.")]); return true; }
    if (d === 50) { Dlg.run([narr("February 14th. Nadia's window has a heart in it cut out of a pie box. Lin's has a rack of cards by the register that Mei has hand-lettered over, because the printed ones were, in her words, cowardly."), narr('You could buy one. You could give it to somebody. That is the whole holiday and it is enough.')]); return true; }
    if (d === 57) { Dlg.run([narr("Presidents' Day. The dock is closed, the bank is closed, and Sol has a sign in the window that says OPEN, BECAUSE WHY WOULDN'T I BE.")]); return true; }
    if (d === 81) { Dlg.run([narr("March 17th. Nadia's pie is green and she will not say what makes it green. Cal is playing something that is not Irish and saying it is.")]); return true; }
    if (d === 84 && !s.spring) { s.spring = true; G.snow = 0; remember('spring'); Dlg.run([narr('March 20th. The first day of spring, and the street has taken it literally: the last of the snow went in the night, and the sidewalk is a sidewalk again, and the puddles are water.'), narr(c.signe && c.signe.arrived ? 'From 410, through an open window for the first time, the cello. She is playing it to the street. The street has stopped to listen, some of it.' : 'Somebody on the fourth floor has opened a window for the first time since December. It was you.')]); return true; }
    if (d === 91) { Dlg.run([narr("Sunday. The first Sunday of spring. Mrs. Ortega has the kitchen going since six; you can smell it on the stairs. Everybody on the street is invited, she says, which she says every Sunday, and means today.")]); return true; }
    if (d === 96) { Dlg.run([narr("April 1st. Cal has told four people the bus is running again. Two of them believed him. Walter would have been the third.")]); return true; }
    return false;
  },
  // New Year's Eve: midnight at the railing
  update() {
    const s = this.S();
    if (G.day === 5 && !s.nye && G.scene === 'street' && G.state === 'play' && G.tod > 0.8 && G.px > 2140 && !Dlg.active) { s.nye = true; G.fireworks = 900; remember('nye_fireworks'); Audio.tone(80, 0.6, 'sine', 0.06); Dlg.run([narr('Midnight, or near enough that the street decides it is. Over the river, from somewhere on the far bank, the first one goes up, and the second, and the water throws them back doubled.'), narr(pick(['Somebody behind you counts down from ten and gets to four and forgets the rest, and everybody laughs, and the year turns over anyway.', 'A woman you do not know puts a paper cup in your hand. It is not coffee. You drink it.'])), narr(G.chars.amos.met && !G.chars.amos.dead ? 'Amos, on the stoop, three hundred feet back, with his hands in his armpits, looking up. He sees you see him. He nods, once, at the sky, like it was his idea.' : 'You are the only one at the railing who came alone, and for four minutes it does not matter at all.')]); }
  },
  // the lights, and helping with them
  lightsUp() { return G.day <= 10 && !this.S().lights; },
  helpItem() {
    const s = this.S(); if (G.day !== 10 || s.lights) return null;
    return { t: 'Help take the lights down', r: '-6 energy', do: () => { if (G.energy < 6) { UI.toast('Not enough in you for a ladder.', '#8ab0d8'); return; } useEnergy(6); s.lights = true; G.flags.grannyHelped = (G.flags.grannyHelped || 0) + 1; remember('lights_down'); Dlg.run([say('granny', "You. Up the ladder. I'm seventy-eight and the boy's nine and between us that's one person who can reach."), narr('You unhook the string from the fire escape one bulb at a time, and hand it down to Sam, who winds it around his elbow the way he has seen somebody do. The awning at Lin\'s. The lamp post. The window at Sol\'s, where Sol holds the ladder and says nothing and does not need to.'), say('granny', "There. Now the year can start. Go inside; you're blue."), narr("Twelfth Night. The street is darker and looks, for the first time, like January.")]); } };
  },
  // a card, and who it goes to
  cardItem(id, line) {
    const s = this.S(); if (!G.inv.vcard || s.card) return null;
    return { t: 'Give them the card', do: () => { G.inv.vcard = 0; s.card = id; remember('card_' + id); if (G.chars[id] && typeof G.chars[id].trust === 'number') G.chars[id].trust += 2; Dlg.run([narr("Mei's lettering on the front, which says nothing about love and everything about it. Inside, your handwriting, which is worse."), say(id, line)]); } };
  },
  endingLines() {
    const s = this.S(); const out = [];
    if (s.card) out.push({ name: "February 14th", line: `A card from Lin's, hand-lettered by Mei, given to ${Home.photoName(s.card).split(' ')[0]}. ${s.card === 'nora' ? 'It is on the refrigerator in 411.' : s.card === 'signe' ? 'It is on the music stand in 410.' : s.card === 'birdie' ? 'She read it on air. Not the inside. The front.' : 'It is somewhere it was kept.'}` });
    if (s.nye) out.push({ name: "New Year's Eve", line: 'Fireworks over the river, from the railing, with a paper cup. The year turned over and you were outside for it.' });
    return out;
  }
};
{
  // mornings, in order: the calendar first, then everybody else
  const weS = wakeEvents; wakeEvents = function () { if (Season.wake()) return; weS.apply(this, arguments); };
  const puS = playUpdate; playUpdate = function () { puS.apply(this, arguments); Season.update(); };
  // the dock keeps hours
  const goS = goScene; goScene = function (to, at) {
    if (to === 'dock' && G.scene === 'street' && CAL.dockClosed(G.day)) { Dlg.run([narr(`The roll-up doors are down and the chain is on. A sign on the middle one, stencil on cardboard: CLOSED SAT-SUN & HOLIDAYS. ${CAL.closedWhy(G.day)}.`), narr(G.flags.vp ? 'Even vice presidents, it turns out.' : G.chars.amos.job ? 'Amos has the day too. He will not know what to do with it either.' : 'Lin\'s still needs runners. Nadia still needs dishes done. The city does not close.')]); return; }
    return goS(to, at);
  };
  const awS = Amos.where; Amos.where = function () { const a = G.chars.amos; if (a.job === 'dock' && CAL.dockClosed(G.day)) { a.job = 'off'; const r = awS.call(this); a.job = 'dock'; return r; } return awS.call(this); };
  // Mrs. Ortega, on the day the lights come down and the first Sunday of spring
  const gmS = Minor.granny; Minor.granny = function () {
    if (G.day === 91 && !Season.S().dinner) { Season.S().dinner = true; G.flags.grannyHelped = (G.flags.grannyHelped || 0) + 1; G.hunger = 100; G.ateToday = true; remember('sunday_dinner'); Dlg.run([say('granny', "Sit. Sit! Don't look at the chair, sit in it."), narr("Her kitchen, on the second floor, which you have never seen: a table for four with nine people at it. Amos, if he is anywhere, is at the end with a plate he is guarding. The boy from the diner is under the table, by choice."), narr('Rice and beans and a pork shoulder that has been in the oven since before you woke, and a flan, and a second flan, because the first one, she says, was for practice.'), say('granny', "Hector did the carving. Now nobody does, so I do. Hold the plate. Hold it! There."), narr('You leave full in a way you had forgotten was available.')]); return; }
    gmS.call(this); const it = Season.helpItem(); if (it && Menu.active) Menu.items.splice(Menu.items.length - 1, 0, it);
  };
  // Valentine's: Mei sells the card, and four people can be given it
  const mmS = Mei.menu; Mei.menu = function () { mmS.call(this); if (Menu.active && G.day >= 50 && G.day <= 52 && !G.inv.vcard && !Season.S().card) Menu.items.splice(Menu.items.length - 1, 0, { t: 'Buy a card', r: '$3', disabled: () => G.money < 3, do: () => { if (!spend(3)) return; G.inv.vcard = 1; Dlg.run([say('mei', "That one. I did that one at two in the morning. It doesn't say 'be mine,' because nobody is anybody's. It says 'you're here.' Which is better."), narr('A card, hand-lettered. It could go to somebody.')]); } }); };
  const CV = (obj, key, id, line) => { const f0 = obj[key]; obj[key] = function () { f0.apply(this, arguments); const it = Season.cardItem(id, line); if (it && Menu.active) Menu.items.splice(Menu.items.length - 1, 0, it); }; };
  CV(Nora, 'menu', 'nora', "...'You're here.' Yeah. I am. I'm going to put this on the fridge and I'm not going to explain it to anybody who asks.");
  CV(Nadia, 'menu', 'nadia', "A card. From you. Sam! Look, a card. ...Don't look, Sam. Go do fractions. ...Thank you. It goes over the pie case, with Dad.");
  if (typeof Cello !== 'undefined') CV(Cello, 'menu', 'signe', "...");
  if (typeof Radio !== 'undefined') CV(Radio, 'menu', 'birdie', "A card. Thirty-one years on the overnight and a card. I'm going to read the front on air. Not the inside. The inside's mine.");
  // the birthday: Nadia's cake, and a call
  const oesS = onEnterScene; onEnterScene = function (sc) { oesS(sc); if (sc === 'diner' && G.day === 43 && G.chars.nadia.met && !G.chars.nadia.closed && !Season.S().cake) { Season.S().cake = true; G.hunger = Math.min(100, G.hunger + 40); trust('nadia', 2); remember('birthday_cake'); Dlg.run([narr('The diner has a sign on the door that says CLOSED FOR A PRIVATE FUNCTION and the private function is you.'), say('nadia', "Sit down. Don't say anything. Sam, the candles."), narr('One candle. She says the number is nobody\'s business, including yours. The cake is a diner cake, which is to say it is the best cake, and Sam sings, badly, and Nadia does not sing and looks at the pie case while he does.'), say('kid', "Make a wish. You have to. It's the law."), narr('You make one. It is not the one you would have made in December.')]); } };
  const pdS = Phone.daily; Phone.daily = function () { pdS.call(this); const P = this.P(); const j = Jo.J(); if (G.day === 43 && (j.stage >= 1 || j.calls > 0) && !j.stopped && !P.doneToday) { P.callToday = 'jo_birthday'; P.delay = 120 + irnd(0, 100); P.attempts = 0; } };
  const paS = Phone.answer; Phone.answer = function () { const P = this.P(); if (P.callToday !== 'jo_birthday') return paS.call(this); P.ringing = false; P.doneToday = true; P.log.push({ day: G.day, who: 'jo' }); useEnergy(2); Audio.sel(); const j = Jo.J(); j.calls++; j.missedRow = 0; j.callDay = G.day; remember('jo_birthday'); Dlg.run([say('jo', "I wasn't going to call. I called. Happy birthday."), say('jo', "The kids made a card. It's a drawing of a house with rain on it, because I told them it rains where you are, and now they think that's all it does."), you("It is."), say('jo', "...Okay. Okay. Happy birthday. I'll put it in the mail. I'll call Thursday. Don't be weird about it.")]); };
  // Birdie and the calendar
  if (typeof Radio !== 'undefined') { const bsS = Radio.buildShow; Radio.buildShow = function () { const segs = bsS.call(this); if (G.day === 5) segs.splice(1, 0, { who: 'birdie', text: "It's the last night of the year. I'm going to count it down at midnight, alone, into a microphone, the way I have for thirty-one years, and if you're at the railing you can count with me. Ten. I'll start at ten. I always start at ten." }); if (G.day === 21 || G.day === 22) segs.splice(1, 0, { who: 'rec', text: '(a record: a man\'s voice, from 1963, all of it, and then nothing for the length of it again)' }); return segs; }; }
  FRESH.busker = FRESH.busker || []; FRESH.busker.push(L_("Six more weeks. Of what? Don't ask me of what. Six more.", () => G.day === 38, 38, 38), L_("The 14's running again. Starting today. ...April Fools. Sorry. Sorry. Walter would've laughed. Would he? He'd have hit me with the cane.", () => G.day === 96, 96, 96), L_("It's Irish. It's not Irish. It's green, which is the important part.", () => G.day === 81, 81, 81));
  FRESH.walter = FRESH.walter || []; FRESH.walter.push(L_("Groundhog Day. Six more weeks of winter, the boy says. Six more weeks. I'd take them. I'd take six more of anything.", () => G.day === 38, 38, 38), L_("New year. Ruth counted them. I stopped at forty-one. It's a good number; I'll stay there.", () => G.day >= 6 && G.day <= 8, 6, 8));
  FRESH.amos = FRESH.amos || []; FRESH.amos.push(L_("Happy birthday. Don't ask how I know; Nadia. Nadia knows everything. I got you nothing; I've got nothing. I've got this coffee, which is yours anyway.", () => G.day === 43, 43, 43), L_("The 14's running. Cal said. ...It's April first, isn't it. That kid.", () => G.day === 96, 96, 96), L_("Snow. I like snow. Nobody believes that. It's quieter than rain and it doesn't get in the cardboard the same.", () => G.weather === 'snow'), L_("Sun. Look at that. I forgot the color of the building across the street.", () => G.weather === 'clear' && G.day < 60));
  FRESH.nadia = FRESH.nadia || []; FRESH.nadia.push(L_("Green pie. Don't ask. Sam did the green. I did the pie.", () => G.day === 81, 81, 81), L_("The heart in the window's a pie box. Sam cut it. He cut it twice, the first one was a kidney.", () => G.day === 50, 50, 50));
  FRESH.sol = FRESH.sol || []; FRESH.sol.push(L_("Presidents' Day. I've been open every Presidents' Day since 1983. The presidents have never once come in.", () => G.day === 57, 57, 57), L_("Snow on the sign. I'll get the ladder. I won't get the ladder. Somebody will do it for me by not doing it.", () => G.weather === 'snow'));
  FRESH.nora = FRESH.nora || []; FRESH.nora.push(L_("Snow day. The ward's full of people who fell on the ice and one who fell off a roof getting the lights down. Don't fall off anything.", () => G.weather === 'snow' && G.day > 3), L_("Sun. Actual sun. I stood in it on the ward roof for eleven minutes and got written up. Worth it.", () => G.weather === 'clear' && G.day < 70));
  FRESH.mei = FRESH.mei || []; FRESH.mei.push(L_("I drew the snow. You can't draw snow, it turns out. You draw everything else and leave the snow.", () => G.weather === 'snow'), L_("The cards. I did forty. My mom said 'who buys a card that says you're here.' Everybody, Mom. Everybody who's here.", () => G.day >= 50 && G.day <= 52, 50, 52));
  const belS = buildEndingList; buildEndingList = function () { return belS().concat(Season.endingLines()); };
}
