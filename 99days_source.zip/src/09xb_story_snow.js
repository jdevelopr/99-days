// ============================================================
// Snow: on the roofs and the sills and the awnings and the lamps, on the sidewalk with tracks in it, on the cars.
// Flakes instead of rain. Snowmen the kids leave. Lights on the street until Twelfth Night. Fireworks, once.
// ============================================================
const Snow = {
  layer: null, painted: -1, flakes: [], sparks: [],
  level() { return G.snow || 0; },
  ensure() {
    const lv = Math.round(this.level() * 20) / 20; if (this.layer && this.painted === lv) return;
    if (!this.layer) { const [c, g] = mkCanvas(STREET.w, H); this.layer = c; this.lg = g; }
    this.paint(this.lg, lv); this.painted = lv;
  },
  // the static part: everything that does not move gets a cap
  paint(g, lv) {
    g.clearRect(0, 0, STREET.w, H); if (lv <= 0.02) return;
    const a = clamp(lv * 1.5, 0, 1); const th = lv < 0.3 ? 1 : lv < 0.65 ? 2 : 3; const gy = GROUND_Y;
    const white = `rgba(236,240,248,${a})`, whiteD = `rgba(236,240,248,${a * 0.85})`, shade = `rgba(180,190,210,${a * 0.6})`;
    const cap = (x, y, w, t) => { px(g, x, y - t, w, t, white); px(g, x, y - t + (t - 1), w, 1, shade); };
    const icicles = (x, y, w) => { if (lv < 0.4) return; const R = seeded(x * 3 + y); for (let ix = x + 2; ix < x + w - 2; ix += 4 + Math.floor(R() * 5)) { const h = 2 + Math.floor(R() * 4); px(g, ix, y, 1, h, `rgba(210,225,245,${a * 0.8})`); } };
    // the sidewalk, with a trampled path along it, and the road with the plow's leavings and the tracks
    px(g, 0, gy + 1, STREET.w, 18, `rgba(236,240,248,${a * 0.8})`);
    { const R = seeded(77 + Math.round(lv * 100)); for (let x = 0; x < STREET.w; x += 6 + Math.floor(R() * 10)) { const w = 4 + Math.floor(R() * 8); px(g, x, gy + 12 + Math.floor(R() * 8), w, 1, `rgba(90,96,112,${a * 0.35})`); if (R() < 0.3) px(g, x + 1, gy + 14 + Math.floor(R() * 6), 2, 1, `rgba(90,96,112,${a * 0.5})`); } }
    px(g, 0, gy + 20, STREET.w, 6, `rgba(230,234,242,${a * 0.65})`); px(g, 0, 262, STREET.w, 8, `rgba(230,234,242,${a * 0.6})`);
    px(g, 0, gy + 26, STREET.w, 36, `rgba(220,226,236,${a * 0.22})`);
    for (const ty of [239, 243, 251, 255]) px(g, 0, ty, STREET.w, 1, `rgba(40,42,52,${a * 0.35})`);
    // buildings
    for (const b of STREET.buildings) {
      const top = gy - b.h; cap(b.x - 1, top - 3, b.w + 2, th);
      const kind = b.kind || 'plain';
      if (kind === 'apartment') { const dx = b.door, dw = 22; cap(dx - 3, gy - 58, dw + 6, th); px(g, dx - 6, gy - 7, dw + 12, 1, whiteD); }
      if (kind === 'store') { const sx = b.x + 10, sw = b.w - 20, aw = sw + 8, ax = sx - 4, ay = gy - 58; cap(ax, ay - 18, aw, th); icicles(ax, ay + 12, aw); }
      if (kind === 'diner') { const sx = b.x + 8, sw = b.w - 16; cap(sx - 4, gy - 52, sw + 8, th); const nx = b.x + b.w / 2, ny = gy - 74; cap(nx - 50, ny - 4, 100, th); icicles(sx - 4, gy - 48, sw + 8); }
      if (kind === 'clinic') { const dx = b.door; cap(dx - 32, gy - 76, 94, th); cap(dx + 4, gy - 62, 18, 1); }
      if (kind === 'warehouse') { for (let i = 0; i < 3; i++) { const dx = b.x + 30 + i * 110; cap(dx - 3, gy - 60, 66, th); } cap(b.x + b.w / 2 - 62, top + 6, 124, th); }
      if (kind === 'laundry') { const sx = b.x + 10, sw = b.w - 20; cap(sx - 4, gy - 62, sw + 8, th); icicles(sx - 4, gy - 50, sw + 8); }
      if (kind === 'pawn') { cap(b.x + 4, gy - 76, b.w - 8, th); cap(b.x + 6, gy - 46, 30, 1); }
      if (b.fireEscape) { const fx = b.x + b.w - 34; const floors = b.floors || 0; for (let f = 0; f < floors; f++) { const fy = gy - GF_H - (f + 1) * FLOOR_H + 12 + 24 + 3; px(g, fx, fy - 1, 30, 1, whiteD); } }
    }
    // sills
    for (const L of World.lights) { if (L.store || L.diner || L.dock || L.door) continue; cap(L.x - 2, L.y + L.h + 2, L.w + 4, Math.min(th, 2)); }
    // lamp heads, and the railing at the river end
    for (const x of STREET.lamps) cap(x - 1, gy - 78, 17, th);
    for (let x = 2140; x < 2460; x += 16) px(g, x, gy - 29, 12, 1, whiteD);
    // the KHRL mast base
    px(g, 2116, gy - 154 - 4, 18, 1, whiteD);
  },
  // the moving parts: props and cars get caps drawn after they are
  caps(g, camX) {
    const lv = this.level(); if (lv <= 0.05 || G.scene !== 'street') return; const a = clamp(lv * 1.5, 0, 1); const th = lv < 0.3 ? 1 : lv < 0.65 ? 2 : 3;
    g.fillStyle = `rgba(236,240,248,${a * 0.9})`;
    for (const p of STREET.props) {
      if (p.hideIf && G.flags[p.hideIf]) continue; if (p.s === 'cardboard' && (G.chars.amos.room || G.flags.amosGone)) continue; if (p.s === 'blanket') continue;
      const spr = SPR[p.s]; if (!spr) continue; const sx = p.x - camX; if (sx + spr.width < 0 || sx > W) continue;
      const t = p.s === 'cardboard' ? 1 : th; g.fillRect(sx + 1, p.y - spr.height, spr.width - 2, t);
    }
    for (const car of STREET.cars) { const spr = SPR[car.red ? 'carRed' : 'car']; const sx = car.x - camX; if (sx + spr.width < 0 || sx > W) continue; g.fillRect(sx + 26, 266 - spr.height, spr.width - 52, th); g.fillRect(sx + 6, 266 - spr.height + 9, spr.width - 12, 1); }
  },
  // the kids' snowmen
  snowmen(g, camX) {
    if (G.scene !== 'street' || !G.snowmen) return;
    for (const s of G.snowmen) {
      const sx = s.x - camX; if (sx < -30 || sx > W + 30) continue;
      const age = G.day - s.built; const slump = clamp(age / 9 + (this.level() < 0.3 ? 0.35 : 0), 0, 1);
      const base = FEET_Y + 1; const r1 = 7 * (1 - slump * 0.3), r2 = 5 * (1 - slump * 0.35), r3 = 4 * (1 - slump * 0.4); const lean = Math.round(slump * 3);
      const ball = (cx, cy, r) => { g.fillStyle = '#f0f4fa'; g.beginPath(); g.ellipse(cx, cy, r, r * (1 - slump * 0.25), 0, 0, Math.PI * 2); g.fill(); g.fillStyle = 'rgba(170,180,200,0.6)'; g.beginPath(); g.ellipse(cx + r * 0.3, cy + r * 0.3, r * 0.6, r * 0.4, 0, 0, Math.PI); g.fill(); };
      const y1 = base - r1, y2 = y1 - r1 * 0.8 - r2 * 0.8, y3 = y2 - r2 * 0.8 - r3 * 0.8;
      ball(sx, y1, r1); ball(sx + lean, y2, r2); ball(sx + lean * 2, y3, r3);
      px(g, sx + lean * 2 - 2, Math.round(y3 - 1), 1, 1, '#2a2a30'); px(g, sx + lean * 2 + 1, Math.round(y3 - 1), 1, 1, '#2a2a30'); px(g, sx + lean * 2, Math.round(y3 + 1), 3, 1, '#e88a3a');
      px(g, sx + lean - r2 - 4, Math.round(y2 - 1), 5, 1, '#5a3a22'); px(g, sx + lean + r2, Math.round(y2 - 2), 5, 1, '#5a3a22');
      px(g, sx + lean - r2 + 1, Math.round(y2 - r2 * 0.8), r2 * 2 - 1, 2, '#c83a3a');
      if (s.hat) { px(g, sx + lean * 2 - 3, Math.round(y3 - r3 - 1), 7, 1, '#3a3a44'); px(g, sx + lean * 2 - 2, Math.round(y3 - r3 - 5), 5, 4, '#3a3a44'); }
      for (let i = 0; i < 3; i++) px(g, sx - 1, Math.round(y1 - r1 * 0.5 + i * 3), 1, 1, '#2a2a30');
    }
  },
  prints(g, camX) { if (!G.prints || G.scene !== 'street') return; g.fillStyle = 'rgba(70,76,92,0.5)'; for (const p of G.prints) { const sx = p.x - camX; if (sx < -4 || sx > W + 4) continue; g.fillRect(sx, p.y, 2, 1); } },
  trackPrints() {
    if (G.scene !== 'street' || this.level() < 0.25 || !G.walking) return; G.prints = G.prints || [];
    const last = G.prints[G.prints.length - 1]; if (last && Math.abs(last.x - G.px) < 7) return;
    G.prints.push({ x: Math.round(G.px + (G.prints.length % 2 ? 3 : -3)), y: FEET_Y - 1 + (G.prints.length % 2) }); if (G.prints.length > 90) G.prints.shift();
  },
  // frozen puddles
  ice(g, camX, pal) {
    for (const p of STREET.puddles) { const [wx, wy, rw, rh] = p; const sx = wx - camX; if (sx + rw < 0 || sx - rw > W) continue; g.fillStyle = 'rgba(205,218,236,0.42)'; g.beginPath(); g.ellipse(sx, wy, rw, rh, 0, 0, Math.PI * 2); g.fill(); g.strokeStyle = 'rgba(240,246,255,0.5)'; g.lineWidth = 1; g.beginPath(); g.moveTo(sx - rw * 0.5, wy - rh * 0.3); g.lineTo(sx + rw * 0.1, wy + rh * 0.2); g.lineTo(sx + rw * 0.5, wy - rh * 0.4); g.stroke(); }
  },
  // flakes
  initFlakes() { this.flakes.length = 0; for (let i = 0; i < 240; i++) this.flakes.push({ x: Math.random() * (W + 40) - 20, y: Math.random() * H, v: 0.35 + Math.random() * 0.7, z: Math.random(), ph: Math.random() * 6.28, s: Math.random() < 0.3 ? 2 : 1 }); },
  fall(g, t, clipRect, camX) {
    const amt = G.snowing || 0; if (amt <= 0.01) return; if (!this.flakes.length) this.initFlakes();
    const n = Math.floor(this.flakes.length * amt);
    const cx = camX || 0; const shift = (this.camX === undefined || Math.abs(cx - this.camX) > W) ? 0 : cx - this.camX; if (!clipRect) this.camX = cx;
    g.save(); if (clipRect) { g.beginPath(); g.rect(...clipRect); g.clip(); }
    for (let i = 0; i < n; i++) {
      const f = this.flakes[i]; if (!clipRect) { f.y += f.v * (0.6 + f.z * 0.7); f.x += Math.sin(f.ph + t * 0.02) * 0.35 - (G.wind || 0) * 0.5 * (0.5 + f.z) - shift * (0.5 + f.z * 0.5); if (f.y > H) { f.y = -4; f.x = Math.random() * (W + 40) - 20; } if (f.x < -20) f.x += W + 40; if (f.x > W + 20) f.x -= W + 40; }
      g.fillStyle = `rgba(240,244,252,${0.45 + f.z * 0.45})`; g.fillRect(Math.round(f.x), Math.round(f.y), f.s, f.s);
    }
    g.restore();
  },
  // breath in the cold
  breath(g, camX, t) {
    if (!G.cold || !isOutdoor(G.scene) || !G.entities) return;
    for (const e of G.entities) { if (e.sprite || e.hidden || e.lying) continue; const ph = (t + Math.round(e.x * 7)) % 170; if (ph > 34) continue; const sx = Math.round(e.x - camX) + (e.dir || 1) * 6; const y = e.y - HUMAN_H + 7 - ph / 5; const r = 1 + ph / 10; g.fillStyle = `rgba(230,236,246,${0.32 * (1 - ph / 34)})`; g.beginPath(); g.ellipse(sx + (e.dir || 1) * ph / 6, y, r * 1.4, r, 0, 0, Math.PI * 2); g.fill(); }
  },
  // the lights, until Twelfth Night
  lights(g, camX, t, pal) {
    if (!Season.lightsUp() || G.scene !== 'street') return; const night = pal ? pal.night : 0;
    const cols = ['#ff4a4a', '#4ae86a', '#ffd84a', '#4a8aff', '#ff8ae8']; let i = 0;
    const bulb = (x, y) => { const sx = x - camX; if (sx < -4 || sx > W + 4) { i++; return; } const c = cols[i % cols.length]; const tw = night > 0.05 ? (Math.sin(t * 0.09 + i * 1.7) > -0.2 ? 1 : 0.3) : 0.55; g.globalAlpha = tw; g.fillStyle = c; g.fillRect(sx, y, 2, 2); if (night > 0.05 && tw > 0.5) { g.globalAlpha = 0.22 * night; g.fillRect(sx - 1, y - 1, 4, 4); } g.globalAlpha = 1; i++; };
    const gy = GROUND_Y; const B = STREET.buildings;
    // Harlan Arms: the roofline, the door, the fire escape
    { const b = B.find(x => x.kind === 'apartment'); const top = gy - b.h; for (let x = b.x + 2; x < b.x + b.w; x += 6) bulb(x, top - 6); const dx = b.door; for (let x = dx - 8; x <= dx + 30; x += 5) bulb(x, gy - 62); const fx = b.x + b.w - 34; for (let f = 0; f < 3; f++) { const fy = gy - GF_H - (f + 1) * FLOOR_H + 12 + 24 + 3; for (let x = fx; x < fx + 30; x += 5) bulb(x, fy + 1); } }
    // Lin's awning
    { const b = B.find(x => x.kind === 'store'); const sx = b.x + 10, sw = b.w - 20, ax = sx - 4, aw = sw + 8, ay = gy - 58; for (let x = ax; x < ax + aw; x += 6) bulb(x, ay + 13); }
    // Nadia's
    { const b = B.find(x => x.kind === 'diner'); const sx = b.x + 8, sw = b.w - 16; for (let x = sx - 4; x < sx + sw + 4; x += 6) bulb(x, gy - 50); }
    // Sol's window
    { const b = B.find(x => x.kind === 'pawn'); for (let x = b.x + 6; x <= b.x + 36; x += 5) bulb(x, gy - 48); for (let y = gy - 44; y < gy - 8; y += 5) { bulb(b.x + 6, y); bulb(b.x + 34, y); } }
    // wreaths on the lamp posts
    for (const x of STREET.lamps) { const sx = x + 1 - camX; if (sx < -10 || sx > W + 10) continue; g.strokeStyle = '#2a6a34'; g.lineWidth = 3; g.beginPath(); g.arc(sx, gy - 58, 5, 0, Math.PI * 2); g.stroke(); g.fillStyle = '#c83a3a'; g.fillRect(sx - 1, gy - 64, 2, 2); g.fillRect(sx - 5, gy - 57, 2, 2); g.fillRect(sx + 3, gy - 57, 2, 2); g.fillRect(sx - 2, gy - 53, 4, 3); }
  },
  // fireworks over the river
  fireworks(g, camX, t) {
    if (!G.fireworks || G.scene !== 'street') return; G.fireworks--;
    if (G.fireworks % 42 === 0 && G.fireworks > 60) { const cx = 2200 + Math.random() * 240, cy = 40 + Math.random() * 60; const col = pick(['#ff6a4a', '#ffd84a', '#8ad8ff', '#ff8ae8', '#c8ffb0', '#ffffff']); for (let k = 0; k < 26; k++) { const an = (k / 26) * Math.PI * 2; const sp = 0.8 + Math.random() * 0.9; this.sparks.push({ x: cx, y: cy, vx: Math.cos(an) * sp, vy: Math.sin(an) * sp, life: 50 + Math.random() * 25, col }); } Audio.tone(60 + Math.random() * 40, 0.4, 'sine', 0.05); }
    for (const s of this.sparks) { s.x += s.vx; s.y += s.vy; s.vy += 0.018; s.vx *= 0.985; s.life--; const sx = s.x - camX; if (sx < 0 || sx > W) continue; g.globalAlpha = clamp(s.life / 40, 0, 1); g.fillStyle = s.col; g.fillRect(Math.round(sx), Math.round(s.y), 2, 2); }
    g.globalAlpha = 1; this.sparks = this.sparks.filter(s => s.life > 0);
    // reflected in the river
    g.globalAlpha = 0.25; for (const s of this.sparks) { const sx = s.x - camX; if (sx < 0 || sx > W) continue; g.fillStyle = s.col; g.fillRect(Math.round(sx), Math.round(2 * 232 - s.y), 2, 1); } g.globalAlpha = 1;
  }
};
{
  // under everything that stands: the snow layer, the ice, the snowmen, the footprints
  const dpW = drawPuddles; drawPuddles = function (g, ents, camX, pal, t) {
    if (G.scene === 'street') { Snow.ensure(); if (Snow.level() > 0.02) g.drawImage(Snow.layer, -camX, 0); }
    const frozen = G.scene === 'street' && Snow.level() > 0.3;
    if (frozen) { const keep = STREET.puddles; STREET.puddles = []; try { dpW(g, ents, camX, pal, t); } finally { STREET.puddles = keep; } Snow.ice(g, camX, pal); }
    else dpW(g, ents, camX, pal, t);
    Snow.prints(g, camX); Snow.snowmen(g, camX);
  };
  // over everything: caps on the props and cars, the lights, the flakes, the breath, the fireworks
  const drW = drawRain; drawRain = function (g, t, camX, clipRect) {
    if (!clipRect) { Snow.caps(g, camX); Snow.lights(g, camX, t, G.pal); Snow.breath(g, camX, t); }
    drW(g, t, camX, clipRect);
    Snow.fall(g, t, clipRect, camX);
    if (!clipRect) Snow.fireworks(g, camX, t);
  };
  const puW = playUpdate; playUpdate = function () { puW.apply(this, arguments); Snow.trackPrints(); };
  // a loaded save from before the calendar gets a sky
  const ldW = load; load = function () { const r = ldW.apply(this, arguments); if (G && G.weather === undefined) Weather.roll(); else if (G) Audio.setWeather(G.weather, G.rain, G.snowing); return r; };
  // the palette: snow days are bright and grey, not dark like rain
  const tp0 = todPalette; todPalette = function (tod, rain) { const p = tp0(tod, rain); if (G && G.weather === 'snow') { const l = v => [Math.min(255, v[0] * 0.92 + 26), Math.min(255, v[1] * 0.92 + 28), Math.min(255, v[2] * 0.92 + 34)]; p.top = l(p.top); p.bot = l(p.bot); p.amb = l(p.amb); p.sun *= 0.5; } else if (G && G.weather === 'clear' && G.day < 84) { p.sun = Math.min(1, p.sun * 1.1); } return p; };
  // the garden under snow: cold frames, or not much
  const gdW = Garden.daily; Garden.daily = function () {
    const s = this.S(); if (!s.unlocked || !s.planted) return gdW.call(this);
    if ((G.snow || 0) > 0.2) s.lastWater = G.day;
    const g0 = s.growth; gdW.call(this); const delta = s.growth - g0;
    if (delta > 0) { let f = 1; if (G.day >= 84) f = 1.6; else if ((G.snow || 0) > 0.15 || G.cold) f = s.coldFrames ? 0.7 : 0.35; s.growth = Math.min(100, g0 + delta * f); }
    if (s.helpers && s.helpers.amos && G.flags.amosTools && !s.coldFrames && G.day < 84) { s.coldFrames = true; s.coldFrameNew = true; }
  };
  const pbW = paintBeds; paintBeds = function (g, camX, t) {
    pbW(g, camX, t); const s = Garden.S(); if (!s.coldFrames || G.day >= 84) return;
    for (const [bx, bw] of [[110, 60], [190, 60], [270, 60]]) { const x = bx - camX, top = GROUND_Y + 14; g.fillStyle = 'rgba(210,225,240,0.35)'; g.fillRect(x - 2, top - 26, bw + 4, 22); g.strokeStyle = 'rgba(120,90,60,0.9)'; g.lineWidth = 1; g.strokeRect(x - 2 + 0.5, top - 26 + 0.5, bw + 4, 22); g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(x + 4, top - 24, bw - 20, 2); }
  };
  const oesW = onEnterScene; onEnterScene = function (sc) { oesW(sc); if (sc === 'garden' && Garden.S().coldFrameNew) { Garden.S().coldFrameNew = false; remember('cold_frames'); Dlg.run([narr("Three low boxes over the beds, plastic sheeting stretched over frames of scrap lumber, the corners joined the way only somebody with the right tools joins a corner. Amos. Under the plastic the ground is dark and not frozen, and something in it is green."), narr('Cold frames. Hector had the plastic in the shed all along; Amos had the tools, since you. The garden is going to make it to spring.')]); } };
}
