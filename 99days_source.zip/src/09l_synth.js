// ============================================================
// The synth. Every instrument in the game's songs, in one place, with no game state in it,
// so the dashboard's music editor can load this same file and the preview is the game's sound.
//   SYNTH.schedule(ctx, dest, spec, t0, opts) schedules a whole song on a WebAudio context and returns its nodes.
// A song spec: { bpm, bar, key, chords: [[semitones, 'M'|'m'], ...], melody: [bar: [[semitone|null, beats], ...], ...], inst: {...} }
// ============================================================
const midiHz = m => 440 * Math.pow(2, (m - 69) / 12);
const SYNTH = {
  // what each instrument does, and its knobs. Everything here can be overridden per song in spec.inst.
  PARTS: ['bass', 'guitar', 'melody', 'cello', 'horn'],
  DEFAULTS: {
    bass: { on: true, vol: 0.05, type: 'sine', cutoff: 2200, attack: 0.012, octave: -1 },          // the root, once a bar
    guitar: { on: true, vol: 0.022, type: 'triangle', cutoff: 2200, attack: 0.012, pattern: 'arp' }, // arpeggio, two hits a beat
    melody: { on: true, vol: 0.06, type: 'triangle', cutoff: 2200, attack: 0.012, octave: 1 },       // the tune, plucked
    cello: { on: false, vol: 0.05, type: 'sawtooth', cutoff: 500, attack: 0.12, octave: -1 },         // bowed root under each bar, a fifth halfway through
    horn: { on: false, vol: 0.035, type: 'square', cutoff: 1700, attack: 0.08, vibrato: 0.006, mode: 'long', crack: 0, octave: 2 }, // long notes of the melody (band) or every note (solo)
  },
  PATTERNS: { arp: [0, 7, 'third+12', 12, 7], low: [0, 7, 12, 7], strum: [0, 'third', 7, 12], none: [] },
  TYPES: ['sine', 'triangle', 'square', 'sawtooth'],
  // the instrument settings for a song: per-song values over the defaults, with the song's kind filling in what it did not say
  inst(spec) {
    const out = {}; const kind = spec.solo ? 'solo' : spec.band ? 'band' : 'busker';
    for (const p of this.PARTS) {
      const d = Object.assign({}, this.DEFAULTS[p]);
      if (kind === 'band' && (p === 'cello' || p === 'horn')) { d.on = true; if (p === 'horn') { d.cutoff = 1800; d.attack = 0.12; d.vibrato = 0; } }
      if (kind === 'solo') { d.on = p === 'horn'; if (p === 'horn') { d.mode = 'all'; d.crack = 4; d.vol = 0.075; d.octave = 1; } }
      out[p] = Object.assign(d, (spec.inst && spec.inst[p]) || {});
    }
    return out;
  },
  beat(spec) { return 60 / spec.bpm; },
  totalBeats(spec) { return spec.chords.length * spec.bar; },
  duration(spec) { return this.totalBeats(spec) * this.beat(spec) + 1.2; },
  // schedule everything. opts: { mute: true } puts the mute in the horn's bell (Sol's), { only: 'melody' } auditions one part
  schedule(ctx, dest, spec, t0, opts) {
    opts = opts || {}; const nodes = []; const beat = this.beat(spec); const I = this.inst(spec); const key = spec.key;
    const on = p => opts.only ? opts.only === p : I[p].on;
    const pluck = (P, m, t, len) => { const o = ctx.createOscillator(), g = ctx.createGain(), fl = ctx.createBiquadFilter(); o.type = P.type; o.frequency.value = midiHz(m); fl.type = 'lowpass'; fl.frequency.value = P.cutoff; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(P.vol, t + P.attack); g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(0.15, len * 1.1)); o.connect(fl); fl.connect(g); g.connect(dest); o.start(t); o.stop(t + len * 1.1 + 0.05); nodes.push(o, g); };
    const bow = (P, m, t, len, vol) => { const o = ctx.createOscillator(), g = ctx.createGain(), fl = ctx.createBiquadFilter(); o.type = P.type; o.frequency.value = midiHz(m); fl.type = 'lowpass'; fl.frequency.value = P.cutoff; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + P.attack); g.gain.setValueAtTime(vol, t + len * 0.8); g.gain.exponentialRampToValueAtTime(0.0001, t + len); o.connect(fl); fl.connect(g); g.connect(dest); o.start(t); o.stop(t + len + 0.05); nodes.push(o, g); };
    const horn = (P, m, t, len, vol, crack) => {
      const o = ctx.createOscillator(), g = ctx.createGain(), fl = ctx.createBiquadFilter(); o.type = P.type; const muted = !!opts.mute;
      const hz = midiHz(m) * (crack ? (1 + (crack % 2 ? -0.03 : 0.025)) : 1); o.frequency.setValueAtTime(hz * 0.985, t); o.frequency.exponentialRampToValueAtTime(hz, t + 0.07);
      fl.type = muted ? 'bandpass' : 'lowpass'; fl.frequency.value = muted ? 1400 : (crack ? Math.min(P.cutoff, 900) : P.cutoff); if (muted) fl.Q.value = 1.4;
      if (!crack && P.vibrato > 0) { const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 5.2; lg.gain.value = hz * P.vibrato; lfo.connect(lg); lg.connect(o.frequency); lfo.start(t + 0.25); lfo.stop(t + len + 0.1); nodes.push(lfo); }
      const v = vol * (muted ? 0.6 : 1) * (crack ? 0.55 : 1); const L = crack ? len * 0.55 : len;
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + (crack ? 0.03 : P.attack)); g.gain.setValueAtTime(v, t + L * 0.75); g.gain.exponentialRampToValueAtTime(0.0001, t + L);
      o.connect(fl); fl.connect(g); g.connect(dest); o.start(t); o.stop(t + L + 0.05); nodes.push(o, g);
    };
    // the chords: bass, guitar, cello
    spec.chords.forEach((ch, bi) => {
      const root = key + ch[0]; const third = ch[1] === 'm' ? 3 : 4; const tb = t0 + bi * spec.bar * beat;
      if (on('bass')) pluck(I.bass, root + 12 * I.bass.octave, tb, beat * spec.bar * 0.9);
      if (on('guitar')) { const pat = (this.PATTERNS[I.guitar.pattern] || this.PATTERNS.arp).map(x => x === 'third+12' ? third + 12 : x === 'third' ? third : x); if (pat.length) for (let k = 0; k < spec.bar * 2; k++) pluck(I.guitar, root + pat[k % pat.length], tb + k * beat / 2, beat * 0.9); }
      if (on('cello')) { bow(I.cello, root + 12 * I.cello.octave, tb, beat * spec.bar, I.cello.vol); bow(I.cello, root + 7 + 12 * I.cello.octave - 12, tb + beat * Math.floor(spec.bar / 2), beat * (spec.bar - Math.floor(spec.bar / 2)), I.cello.vol * 0.6); }
    });
    // the tune: melody plucked, horn on top
    let tm = t0, n = 0; const H = I.horn;
    spec.melody.forEach((bar, bi) => { bar.forEach(([note, b]) => {
      if (note !== null) { n++;
        if (on('melody')) pluck(I.melody, key + 12 * I.melody.octave + note, tm, b * beat);
        if (on('horn')) { if (H.mode === 'all') horn(H, key + 12 * H.octave + note, tm, b * beat * 0.92, H.vol, n <= (H.crack || 0) ? n : 0); else if (b >= 2 && bi >= 2) { if (H.vibrato > 0 || opts.mute) horn(H, key + 12 * H.octave + note, tm + 0.03, b * beat * 0.9, bi === 2 ? H.vol * 0.6 : H.vol, 0); else bow(H, key + 12 * H.octave + note, tm + 0.03, b * beat * 0.9, bi === 2 ? H.vol * 0.6 : H.vol); } }
      }
      tm += b * beat; }); });
    return { nodes, beat, dur: this.duration(spec) };
  },
  // fade everything out now (walking away)
  hush(ctx, nodes) { try { const now = ctx.currentTime; for (const n of nodes) { if (n.gain) { n.gain.cancelScheduledValues(now); n.gain.setTargetAtTime(0.0001, now, 0.05); } if (n.stop) { try { n.stop(now + 0.3); } catch (e) { } } } } catch (e) { } },
};
