// ============================================================
// The journal: a calendar, the people, the days, the photographs. J, or the pause menu.
// ============================================================
const Journal = {
  tab: 0, TABS: ['Calendar', 'People', 'Days', 'Photos'], scroll: 0, month: 0, from: 'play',
  open(from) { this.from = from || 'play'; this.tab = 0; this.scroll = 0; this.month = CAL.dateOf(G.day).m; G.state = 'journal'; Audio.sel(); G.dayLog = G.dayLog || {}; if (!G.dayLog[1]) G.dayLog[1] = 'The doctor said ninety-nine days. Maybe more, if the trial comes through.'; },
  close() { G.state = 'play'; Audio.blip(); },
  update() {
    if (Input.hit('back') || Input.hit('menu') || Input.hit('journal')) { this.close(); return; }
    if (Input.hit('left')) { if (this.tab === 0 && this.month > 0 && this.month > CAL.dateOf(1).m) { this.month--; } else { this.tab = (this.tab + this.TABS.length - 1) % this.TABS.length; this.scroll = 0; } Audio.blip(); }
    if (Input.hit('right')) { if (this.tab === 0 && this.month < CAL.dateOf(99).m) { this.month++; } else { this.tab = (this.tab + 1) % this.TABS.length; this.scroll = 0; } Audio.blip(); }
    if (Input.hit('act')) { this.tab = (this.tab + 1) % this.TABS.length; this.scroll = 0; Audio.blip(); }
    if (Input.hit('up')) this.scroll = Math.max(0, this.scroll - 1);
    if (Input.hit('down')) this.scroll++;
  },
  // ---- what is coming ----
  events() {
    const out = []; const d = G.day; const f = G.flags; const c = G.chars;
    const add = (day, text, kind) => { if (day >= 1 && day <= 99) out.push({ day, text, kind: kind || 'mine' }); };
    for (const k in CAL.EVENTS) { const day = +k; if (day === 43 && d < 43) continue; add(day, CAL.EVENTS[k], CAL.HOLIDAYS[k] ? 'closed' : 'public'); }
    if (Rent.active()) { const r = Rent.S(); for (let day = r.nextDay; day <= 99; day += 7) add(day, `Rent, $${RENT}${r.owed ? ` (and $${r.owed} owed)` : ''}`); }
    if (f.nanoPaid) { for (let day = f.nanoNext; day <= Math.min(99, f.nanoNext + 20); day += 2) add(day, 'The shot, at the clinic'); }
    else if (f.cureKnown && !f.curePaid && d < 44) add(44, "Dr. Okafor's check");
    if (c.signe && c.signe.band) { for (let day = d; day <= Math.min(99, d + 28); day++) if (day % 7 === 5) add(day, 'The Three, under the shelter'); }
    if (c.signe && c.signe.auditionDay && !c.signe.audition) add(c.signe.auditionDay, "Signe's audition");
    if (c.signe && c.signe.duetDay && !c.signe.duet) add(c.signe.duetDay, 'Signe and Cal, on the corner, after dark');
    if (c.signe && c.signe.bandDay && !c.signe.band) add(c.signe.bandDay, 'Sol brings the horn. Friday, after dark');
    if (c.birdie && c.birdie.leaseKnown && !c.birdie.lease) add(LEASE_DAY, 'The tower lease runs out', 'bad');
    if (c.birdie && c.birdie.callinDay && !c.birdie.lease) add(c.birdie.callinDay, 'The call-in night, KHRL');
    if (c.birdie && c.birdie.sessionDay && !c.birdie.session) add(c.birdie.sessionDay, 'The Three, live on KHRL');
    { const j = G.phone && G.phone.jo; if (j && j.coming && !j.visited) add(j.visitDay, 'Jo comes. The 10:40'); }
    if (f.busPassDay) add(f.busPassDay + 30, 'The bus pass runs out');
    if (G.garden && G.garden.planted && G.garden.ready === 0 && G.garden.lastHarvest) add(G.garden.lastHarvest + 3, 'The garden may be ready');
    if (G.house && G.house.listed && !G.house.owner && G.house.listDay) add(G.house.listDay + 14, 'The Ashby house: somebody will buy it', 'bad');
    add(99, 'Day ninety-nine', 'bad');
    return out.sort((a, b) => a.day - b.day);
  },
  // ---- people, in one line each ----
  people() {
    const c = G.chars, f = G.flags; const P = [];
    const put = (name, line) => P.push({ name, line });
    if (c.amos.met) put('Amos', c.amos.dead ? 'Gone. The candle on the stoop is yours.' : c.amos.room ? `The basement room. ${c.amos.job ? 'Working. ' : ''}${c.amos.tools ? 'He has his tools back.' : 'He does not have his tools.'}` : c.amos.job ? 'Working the dock, sleeping on the cardboard.' : `On the stoop. ${c.amos.fed ? `You have fed him ${c.amos.fed} times.` : 'You have not fed him.'}`);
    else if (G.day >= 2) put('The man by the stoop', c.amos.dead ? 'Flowers on the cardboard. Somebody knew him.' : 'You have not spoken to him.');
    if (c.mei.met) put('Mei', c.mei.accepted ? 'Accepted to the program. She has told her mother.' : c.mei.applied ? 'Applied. Waiting for the envelope.' : c.mei.cold ? 'She rings you up and does not look up.' : `Behind the counter at Lin's, drawing. ${c.mei.textbook ? 'She has the Bridgman.' : ''}`);
    if (c.walter.met) put('Walter', c.walter.dead ? `Died on day ${c.walter.deadDay}. St. Bartholomew's, beside Ruth.` : `The bench under the bus sign. ${c.walter.radio ? 'The radio works. ' : ''}${c.walter.ruthWatch ? "He has Ruth's watch. " : ''}${c.walter.chess ? 'Knight first.' : ''}`);
    if (c.nadia.met) put('Nadia', c.nadia.closed ? 'The diner is closed. Dayton.' : c.nadia.saved ? `The diner is open; you are the reason. ${c.nadia.sam ? 'Sam does fractions in the booth.' : ''}` : `The diner. ${c.nadia.customers || 0} customers you sent. ${c.nadia.sam ? 'Sam is hers.' : ''}`);
    if (c.nora && c.nora.met) put('Nora', c.nora.cold ? 'Next door. She keeps to her side of the wall.' : c.nora.person ? 'Your person on the form. She knows what it says.' : `411. Nights on the ward. ${c.nora.told ? 'She knows.' : 'She does not know yet.'}`);
    if (c.theo && (c.theo.visits > 0 || c.theo.reunited)) put('Theo', c.theo.reunited ? "Back on the corner with Cal, hood down." : c.theo.gone ? 'Gone from the railing.' : 'The kid at the railing with the marker.');
    if (nameKnown('cal')) put('Cal', `The corner, under the shelter. ${f.buskerTips || 0} tips. ${c.signe && c.signe.dating ? 'Two coffees, no guitar, mornings, at 410.' : ''}`);
    if (c.sol && c.sol.met) put('Sol', c.sol.cold ? 'The ledger. Your name is in it.' : `Behind the wire. ${c.sol.played ? 'He played the horn for you. ' : ''}${c.sol.ledger ? 'You have seen the book.' : ''}`);
    if (c.emmett && c.emmett.met) put('Emmett', c.emmett.gone ? 'Out past the point.' : c.emmett.lenaCame ? 'Lena came to the lake.' : `The cabin at the end of the 14. ${c.emmett.mailed ? 'The letter went.' : c.emmett.letter ? 'There is a letter he has not sent.' : ''}`);
    if (c.signe && c.signe.arrived) put(c.signe.met ? 'Signe' : 'The woman in 410', c.signe.audition === 'yes' ? 'On the symphony list. The window is open.' : c.signe.band ? 'Fridays under the shelter with Cal and Sol.' : c.signe.met ? `${c.signe.talks} conversations, most of them short. Practicing 4-6.` : 'A cello through two walls, four to six.');
    if (c.birdie && (c.birdie.met || c.birdie.heard)) put(c.birdie.met ? 'Birdie' : 'The woman on the radio', c.birdie.dark ? 'The tower is dark. She still goes up.' : c.birdie.lease ? 'The tower is paid for the year.' : c.birdie.leaseKnown ? `The tower lease: day ${LEASE_DAY}. ${c.birdie.pledges.length} of five will call.` : c.birdie.met ? `KHRL, top floor, after nine. ${c.birdie.shifts} nights of weather.` : 'KHRL 1340, the overnight.');
    { const j = G.phone && G.phone.jo; if (j && (j.stage >= 1 || j.calls > 0 || j.stopped)) put('Jo', j.visited ? 'She came. She took the 10:40.' : j.stopped ? 'She said she would stop calling.' : j.coming ? `Coming on day ${j.visitDay}.` : `${j.calls} calls. The number is the same.`); }
    if (nameKnown('ortega')) put('Mrs. Ortega', `Second floor, oranges. ${G.garden && G.garden.unlocked ? "Hector's plot is yours to keep." : ''}`);
    if (f.dogFollows || f.dogCollar) put(f.dogName || 'The dog', f.dogFollows ? 'Follows you. Sleeps on the bed, which is not allowed.' : 'Collared. Yours, in the way a dog is anybody\'s.');
    if (c.morrow && c.morrow.met) put('Morrow', c.morrow.asked ? `The super. He asked who gets the room; you said ${c.morrow.answer}.` : `The super, first floor, block capitals. ${c.morrow.radiator ? 'The radiator works.' : ''}`);
    put('Dr. Okafor', f.nanoPaid ? `Nanobots. ${f.nanoShots || 0} shots.` : f.curePaid ? 'Halvorsen. Paid.' : f.cureKnown ? 'Halvorsen: $' + CURE_COST + '.' : `${G.pills} pills left.`);
    return P;
  },
  // ---- drawing ----
  draw(g, t) {
    buildEntities(); renderScene(g, t);
    g.fillStyle = 'rgba(4,5,9,0.86)'; g.fillRect(0, 0, W, H);
    UI.panel(g, 20, 8, W - 40, H - 16, 0.9);
    // tabs
    let tx = 30; for (let i = 0; i < this.TABS.length; i++) { const on = i === this.tab; const w = textWidth(this.TABS[i]) + 10; if (on) { g.fillStyle = 'rgba(232,200,74,0.15)'; g.fillRect(tx - 4, 12, w, 12); } drawText(g, this.TABS[i], tx, 14, on ? '#e8c84a' : '#6a7080'); tx += w + 8; }
    drawText(g, `${CAL.long(G.day)}  -  day ${G.day}`, W - 30, 14, '#8a92a4', { align: 'right' });
    px(g, 28, 26, W - 56, 1, 'rgba(255,255,255,0.12)');
    if (this.tab === 0) this.drawCalendar(g); else if (this.tab === 1) this.drawList(g, this.people().map(p => ({ h: p.name, t: p.line }))); else if (this.tab === 2) this.drawDays(g); else this.drawPhotos(g);
    UI.drawHint(g, `${UI.keyName('act')} next tab   arrows move   ${UI.keyName('back')} close`);
  },
  drawCalendar(g) {
    const m = this.month; const len = CAL.LEN[m]; const first = CAL.dayOf(m, 1); const x0 = 32, y0 = 58, cw = 22, ch = 16;
    drawText(g, `${m > CAL.dateOf(1).m ? '< ' : '  '}${CAL.MONTHS[m]}${m < CAL.dateOf(99).m ? ' >' : ''}`, x0 + 76, 32, '#f0ead8', { align: 'center' });
    for (let i = 0; i < 7; i++) drawText(g, 'SMTWTFS'[i], x0 + i * cw + 8, y0 - 10, '#5a6274', { align: 'center' });
    const ev = this.events(); const byDay = {}; for (const e of ev) (byDay[e.day] = byDay[e.day] || []).push(e);
    for (let dd = 1; dd <= len; dd++) {
      const day = first + dd - 1; const inGame = day >= 1 && day <= 99; const wd = ((day % 7) + 7) % 7; const row = Math.floor((dd - 1 + (((first % 7) + 7) % 7)) / 7);
      const cx = x0 + wd * cw, cy = y0 + row * ch;
      if (day === G.day) { g.fillStyle = 'rgba(232,200,74,0.22)'; g.fillRect(cx, cy - 2, cw - 2, ch - 2); }
      const col = !inGame ? '#3a3f4a' : day < G.day ? '#5a6274' : CAL.dockClosed(day) ? '#c8b070' : '#d8dce8';
      drawText(g, String(dd), cx + 8, cy, col, { align: 'center' });
      if (inGame && byDay[day]) { const k = byDay[day][0].kind; g.fillStyle = k === 'bad' ? '#e86a6a' : k === 'public' || k === 'closed' ? '#c8b070' : '#8ab0d8'; g.fillRect(cx + 6, cy + 9, 4, 2); }
      if (inGame && day < G.day && G.dayLog && G.dayLog[day] && Weather.kind(day) === 'snow') { g.fillStyle = '#e8f0ff'; g.fillRect(cx + 1, cy + 9, 2, 2); }
    }
    // the list: what is coming
    const lx = 200, ly = 32; drawText(g, 'Coming', lx, ly, '#f0ead8');
    const up = ev.filter(e => e.day >= G.day).slice(this.scroll, this.scroll + 12); let y = ly + 12;
    if (!up.length) drawText(g, 'Nothing written down.', lx, y, '#6a7080');
    for (const e of up) { const when = e.day === G.day ? 'Today' : e.day === G.day + 1 ? 'Tomorrow' : CAL.short(e.day); drawText(g, when, lx, y, e.kind === 'bad' ? '#e86a6a' : e.kind === 'public' || e.kind === 'closed' ? '#c8b070' : '#8ab0d8'); drawText(g, e.text + (e.kind === 'closed' ? ' (dock closed)' : ''), lx + 74, y, '#c8ccd8'); y += 12; if (y > H - 30) break; }
    drawText(g, `${Weather.label(G.weather)}${G.snow > 0.1 ? ', snow on the ground' : ''}${G.cold ? ', cold' : ''}.  ${CAL.dockClosed(G.day) ? 'The dock is closed today.' : 'The dock is open.'}`, x0, H - 36, '#8a92a4');
  },
  drawList(g, items) {
    let y = 32; const rows = items.slice(this.scroll); if (!rows.length) drawText(g, 'Nobody yet.', 32, y, '#6a7080');
    for (const it of rows) { drawText(g, it.h, 32, y, '#e8c84a'); const lines = wrapText(it.t, 300); lines.forEach((ln, i) => drawText(g, ln, 140, y + i * 10, '#c8ccd8')); y += Math.max(1, lines.length) * 10 + 4; if (y > H - 34) break; }
  },
  drawDays(g) {
    const log = G.dayLog || {}; const days = []; for (let d = G.day; d >= 1; d--) if (log[d]) days.push(d);
    const items = days.map(d => ({ h: `${CAL.short(d)}`, t: `${log[d]}${CAL.event(d) ? '  (' + CAL.event(d) + ')' : ''}` }));
    if (!items.length) items.push({ h: '', t: 'The days will be here as they happen.' });
    this.drawList(g, items);
  },
  drawPhotos(g) {
    const f = G.flags; const items = [];
    if (f.photos && f.photos.length) for (const p of f.photos) items.push({ h: 'Photo', t: Home.photoName(p) });
    if (G.inv.drawing) items.push({ h: 'Sketch', t: "Mei's drawing of you, from the counter, in pencil." });
    if (f.joLetterDay && f.joWrote) items.push({ h: 'Letter', t: "Jo's, two pages, and a drawing of a house in the rain by somebody who is four." });
    if (f.emmettWrote) items.push({ h: 'Postcard', t: 'A lake on the front, not his. GOT IT. FISH ARE BITING.' });
    if (G.inv.chess) items.push({ h: 'Kept', t: "Walter's chess set. Knight first." });
    if (G.inv.bird) items.push({ h: 'Kept', t: "Amos's carved bird. A wren; they sing louder than their size." });
    if (G.inv.thermos) items.push({ h: 'Kept', t: "Nora's thermos." });
    if (!items.length) items.push({ h: '', t: 'Nothing kept yet. The camera at Sol\'s takes six.' });
    this.drawList(g, items);
  }
};
{
  Input.map.KeyJ = 'journal';
  const puJ = playUpdate; playUpdate = function () { puJ.apply(this, arguments); if (G.state === 'play' && Input.hit('journal')) Journal.open('play'); };
  const pmJ = pauseMenu; pauseMenu = function () { pmJ(); if (Menu.active) Menu.items.splice(2, 0, { t: 'Journal', do: () => Journal.open('menu') }); };
  const dlJ = dayLine; dayLine = function () { const l = dlJ.apply(this, arguments); G.dayLog = G.dayLog || {}; G.dayLog[G.day] = l; return l; };
}
